var class_file_surfer_1_1_models_1_1_windows_file_restorer =
[
    [ "DoVerb", "class_file_surfer_1_1_models_1_1_windows_file_restorer.html#a4fbc62cc5c400c18bb16ef86a89f83b1", null ],
    [ "RestoreEntry", "class_file_surfer_1_1_models_1_1_windows_file_restorer.html#a5d9d25f34cf9e0626e4288b01988d28d", null ],
    [ "BinFolderID", "class_file_surfer_1_1_models_1_1_windows_file_restorer.html#a65092f9484e9511fa70085532cff4ac7", null ],
    [ "NameColumn", "class_file_surfer_1_1_models_1_1_windows_file_restorer.html#a01ad5c793bab4a6faebd13a1e7f5b876", null ],
    [ "PathColumn", "class_file_surfer_1_1_models_1_1_windows_file_restorer.html#a55cd037364bedb8152547c139f4540ba", null ],
    [ "RestoreVerb", "class_file_surfer_1_1_models_1_1_windows_file_restorer.html#ac9f60985469bb913cd19c3f92d077f0d", null ]
];