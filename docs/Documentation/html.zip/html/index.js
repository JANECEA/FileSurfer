var index =
[
    [ "Overview", "index.html#autotoc_md1", null ],
    [ "Namespaces, Classes, and Interfaces", "index.html#autotoc_md2", [
      [ "FileSurfer", "index.html#autotoc_md3", null ],
      [ "FileSurfer.Models", "index.html#autotoc_md4", [
        [ "FileSurfer.Models.FileInformation", "index.html#autotoc_md5", null ],
        [ "FileSurfer.Models.VersionControl", "index.html#autotoc_md6", null ],
        [ "FileSurfer.Models.Shell", "index.html#autotoc_md7", null ],
        [ "FileSurfer.Models.FileOperations", "index.html#autotoc_md8", null ],
        [ "FileSurfer.Models.FileOperations.Undoable", "index.html#autotoc_md9", null ]
      ] ],
      [ "FileSurfer.ViewModels", "index.html#autotoc_md10", null ],
      [ "FileSurfer.Views", "index.html#autotoc_md11", null ]
    ] ]
];