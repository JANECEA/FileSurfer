var dir_9a910ec909ac6a1225ab0744c22119f3 =
[
    [ "Interfaces", "dir_5626a86c095640f395b2e856d5963952.html", "dir_5626a86c095640f395b2e856d5963952" ],
    [ "Models", "dir_7d1d8612535ed6b34f53e0ecba62cb52.html", "dir_7d1d8612535ed6b34f53e0ecba62cb52" ],
    [ "ViewModels", "dir_268632d711ba7a5cd286b1878811c498.html", "dir_268632d711ba7a5cd286b1878811c498" ],
    [ "Views", "dir_aad98f1c2770dbe5e65efbb1a3ccd731.html", "dir_aad98f1c2770dbe5e65efbb1a3ccd731" ],
    [ "App.axaml.cs", "_app_8axaml_8cs.html", "_app_8axaml_8cs" ],
    [ "FileSurferSettings.cs", "_file_surfer_settings_8cs.html", "_file_surfer_settings_8cs" ],
    [ "FileSystemEntry.cs", "_file_system_entry_8cs.html", "_file_system_entry_8cs" ],
    [ "Program.cs", "_program_8cs.html", "_program_8cs" ],
    [ "ViewLocator.cs", "_view_locator_8cs.html", "_view_locator_8cs" ]
];