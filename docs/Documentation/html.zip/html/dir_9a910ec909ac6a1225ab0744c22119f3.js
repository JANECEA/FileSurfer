var dir_9a910ec909ac6a1225ab0744c22119f3 =
[
    [ "Interfaces", "dir_5626a86c095640f395b2e856d5963952.html", "dir_5626a86c095640f395b2e856d5963952" ],
    [ "Models", "dir_7d1d8612535ed6b34f53e0ecba62cb52.html", "dir_7d1d8612535ed6b34f53e0ecba62cb52" ],
    [ "ViewModels", "dir_268632d711ba7a5cd286b1878811c498.html", "dir_268632d711ba7a5cd286b1878811c498" ],
    [ "Views", "dir_aad98f1c2770dbe5e65efbb1a3ccd731.html", "dir_aad98f1c2770dbe5e65efbb1a3ccd731" ],
    [ "App.axaml.cs", "App_8axaml_8cs.html", "App_8axaml_8cs" ],
    [ "FileSurferSettings.cs", "FileSurferSettings_8cs.html", "FileSurferSettings_8cs" ],
    [ "FileSystemEntry.cs", "FileSystemEntry_8cs.html", "FileSystemEntry_8cs" ],
    [ "Program.cs", "Program_8cs.html", "Program_8cs" ],
    [ "ViewLocator.cs", "ViewLocator_8cs.html", "ViewLocator_8cs" ]
];