var IUndoableFileOperation_8cs =
[
    [ "FileSurfer.Models.UndoableFileOperations.IUndoableFileOperation", "interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation.html", "interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation" ]
];