var searchData=
[
  ['undoredohandler_0',['UndoRedoHandler',['../classFileSurfer_1_1Models_1_1UndoRedoHandler.html',1,'FileSurfer::Models']]],
  ['undoredohandler_3c_20iundoablefileoperation_20_3e_1',['UndoRedoHandler&lt; IUndoableFileOperation &gt;',['../classFileSurfer_1_1Models_1_1UndoRedoHandler.html',1,'FileSurfer::Models']]],
  ['undoredohandler_3c_20string_20_3e_2',['UndoRedoHandler&lt; string &gt;',['../classFileSurfer_1_1Models_1_1UndoRedoHandler.html',1,'FileSurfer::Models']]],
  ['undoredonode_3',['UndoRedoNode',['../classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html',1,'FileSurfer::Models::UndoRedoHandler']]]
];
