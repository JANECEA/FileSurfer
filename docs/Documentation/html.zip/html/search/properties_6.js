var searchData=
[
  ['gitintegration_0',['GitIntegration',['../classFileSurfer_1_1FileSurferSettings.html#a634cbce50d2df5f60d61abf2d7d347fe',1,'FileSurfer::FileSurferSettings']]],
  ['gobackcommand_1',['GoBackCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a1dfb71079d69f678b45890016c8ee7bb',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['goforwardcommand_2',['GoForwardCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a0445bfbd66860564cae1df1f088cc68a',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['goupcommand_3',['GoUpCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a447b416af284dbd6c42a0f2b522c49e6',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
