var searchData=
[
  ['gitintegration_0',['GitIntegration',['../class_file_surfer_1_1_file_surfer_settings.html#a634cbce50d2df5f60d61abf2d7d347fe',1,'FileSurfer::FileSurferSettings']]],
  ['gobackcommand_1',['GoBackCommand',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a1dfb71079d69f678b45890016c8ee7bb',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['goforwardcommand_2',['GoForwardCommand',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a0445bfbd66860564cae1df1f088cc68a',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
