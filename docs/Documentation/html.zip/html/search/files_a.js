var searchData=
[
  ['windowsfileiohandler_2ecs_0',['WindowsFileIOHandler.cs',['../_windows_file_i_o_handler_8cs.html',1,'']]],
  ['windowsfilerestorer_2ecs_1',['WindowsFileRestorer.cs',['../_windows_file_restorer_8cs.html',1,'']]],
  ['windowsshellhandler_2ecs_2',['WindowsShellHandler.cs',['../_windows_shell_handler_8cs.html',1,'']]]
];
