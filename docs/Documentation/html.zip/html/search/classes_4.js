var searchData=
[
  ['filenamegenerator_0',['FileNameGenerator',['../class_file_surfer_1_1_models_1_1_file_name_generator.html',1,'FileSurfer::Models']]],
  ['filesurfersettings_1',['FileSurferSettings',['../class_file_surfer_1_1_file_surfer_settings.html',1,'FileSurfer']]],
  ['filesystementry_2',['FileSystemEntry',['../class_file_surfer_1_1_file_system_entry.html',1,'FileSurfer']]]
];
