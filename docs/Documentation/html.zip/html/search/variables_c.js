var searchData=
[
  ['thispclabel_0',['ThisPCLabel',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a7bb1d8e9fefe571ef58da14f5cb12ca3',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
