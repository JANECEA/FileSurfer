var searchData=
[
  ['app_2eaxaml_2ecs_0',['App.axaml.cs',['../App_8axaml_8cs.html',1,'']]],
  ['archivemanager_2ecs_1',['ArchiveManager.cs',['../ArchiveManager_8cs.html',1,'']]]
];
