var searchData=
[
  ['ifileiohandler_2ecs_0',['IFileIOHandler.cs',['../IFileIOHandler_8cs.html',1,'']]],
  ['iundoablefileoperation_2ecs_1',['IUndoableFileOperation.cs',['../IUndoableFileOperation_8cs.html',1,'']]],
  ['iversioncontrol_2ecs_2',['IVersionControl.cs',['../IVersionControl_8cs.html',1,'']]]
];
