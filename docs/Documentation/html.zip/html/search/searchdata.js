var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwz",
  1: "acdefgimnprsuvw",
  2: "f",
  3: "acefgimptuvw",
  4: "abcdefgiklmnoprstuvwz",
  5: "_bcdfhlmnprst",
  6: "b",
  7: "dsv",
  8: "dilnstu",
  9: "abcdefgilmnopqrstuv",
  10: "st"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "properties",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Properties",
  10: "Pages"
};

