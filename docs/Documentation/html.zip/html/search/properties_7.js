var searchData=
[
  ['icon_0',['Icon',['../classFileSurfer_1_1FileSystemEntry.html#a5d500d9480e0ce99883230dcc578feee',1,'FileSurfer::FileSystemEntry']]],
  ['invertselectioncommand_1',['InvertSelectionCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#afd0afa7ab802d1167f7af563026dca29',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['isarchived_2',['IsArchived',['../classFileSurfer_1_1FileSystemEntry.html#ad837e4da4e178dfe04ddfab30acdf123',1,'FileSurfer::FileSystemEntry']]],
  ['iscutoperation_3',['IsCutOperation',['../classFileSurfer_1_1Models_1_1ClipboardManager.html#adcce936d4ab1ec3cb9a62d821f5409fe',1,'FileSurfer::Models::ClipboardManager']]],
  ['isdirectory_4',['IsDirectory',['../classFileSurfer_1_1FileSystemEntry.html#a5e7c71bbe6f773038af2db0a7424cfda',1,'FileSurfer::FileSystemEntry']]],
  ['isversioncontrolled_5',['IsVersionControlled',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#aba8d6fca72e535ad166f84417d54fecd',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
