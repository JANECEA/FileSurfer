var searchData=
[
  ['binfolderid_0',['BinFolderID',['../classFileSurfer_1_1Models_1_1WindowsFileRestorer.html#a65092f9484e9511fa70085532cff4ac7',1,'FileSurfer::Models::WindowsFileRestorer']]],
  ['bitmap_1',['Bitmap',['../FileSystemEntry_8cs.html#a43ced1cda6840fdc326fbc42aa835b2e',1,'FileSystemEntry.cs']]],
  ['branches_2',['Branches',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a947a29d2da3712f10f5c35930adcbf17',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['build_3',['Build',['../classFileSurfer_1_1ViewLocator.html#a9fff45e1c4bc9e4d55de8ef18086d72a',1,'FileSurfer::ViewLocator']]],
  ['buildavaloniaapp_4',['BuildAvaloniaApp',['../classFileSurfer_1_1Program.html#a0476e14fde032df06d8e38bc5368c6b3',1,'FileSurfer::Program']]],
  ['byteunits_5',['ByteUnits',['../classFileSurfer_1_1FileSystemEntry.html#a3fa85d8099554197865096f8b1f03456',1,'FileSurfer::FileSystemEntry']]]
];
