var searchData=
[
  ['binfolderid_0',['BinFolderID',['../class_file_surfer_1_1_models_1_1_windows_file_restorer.html#a65092f9484e9511fa70085532cff4ac7',1,'FileSurfer::Models::WindowsFileRestorer']]],
  ['bitmap_1',['Bitmap',['../_file_system_entry_8cs.html#a43ced1cda6840fdc326fbc42aa835b2e',1,'FileSystemEntry.cs']]],
  ['branches_2',['Branches',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a947a29d2da3712f10f5c35930adcbf17',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['build_3',['Build',['../class_file_surfer_1_1_view_locator.html#a9fff45e1c4bc9e4d55de8ef18086d72a',1,'FileSurfer::ViewLocator']]],
  ['buildavaloniaapp_4',['BuildAvaloniaApp',['../class_file_surfer_1_1_program.html#a0476e14fde032df06d8e38bc5368c6b3',1,'FileSurfer::Program']]]
];
