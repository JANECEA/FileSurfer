var searchData=
[
  ['gitversioncontrolhandler_2ecs_0',['GitVersionControlHandler.cs',['../GitVersionControlHandler_8cs.html',1,'']]]
];
