var searchData=
[
  ['clipboardmanager_2ecs_0',['ClipboardManager.cs',['../_clipboard_manager_8cs.html',1,'']]]
];
