var searchData=
[
  ['clipboardmanager_2ecs_0',['ClipboardManager.cs',['../ClipboardManager_8cs.html',1,'']]]
];
