var searchData=
[
  ['duplicatefiles_0',['DuplicateFiles',['../classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1DuplicateFiles.html',1,'FileSurfer::Models::UndoableFileOperations']]]
];
