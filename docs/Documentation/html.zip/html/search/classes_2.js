var searchData=
[
  ['duplicatefiles_0',['DuplicateFiles',['../class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html',1,'FileSurfer::Models::UndoableFileOperations']]]
];
