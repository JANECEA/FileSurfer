var searchData=
[
  ['errormessage_0',['ErrorMessage',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a4b968fbd68b70dbf5413902e3864dda1',1,'FileSurfer.ViewModels.MainWindowViewModel.ErrorMessage'],['../class_file_surfer_1_1_views_1_1_error_window.html#a48852e4b5589edca82c79bfa07778a42',1,'FileSurfer.Views.ErrorWindow.ErrorMessage']]]
];
