var searchData=
[
  ['branches_0',['Branches',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a947a29d2da3712f10f5c35930adcbf17',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
