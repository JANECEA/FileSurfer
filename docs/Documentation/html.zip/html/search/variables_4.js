var searchData=
[
  ['fmask_0',['fMask',['../structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a7d06d15b81af683ce35b5e6c12a50f0b',1,'FileSurfer::Models::WindowsFileProperties::ShellExecuteInfo']]],
  ['foldericon_1',['FolderIcon',['../classFileSurfer_1_1FileSystemEntry.html#aee2f31693a945e767d8feef01b4f4d89',1,'FileSurfer::FileSystemEntry']]]
];
