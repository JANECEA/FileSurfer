var searchData=
[
  ['undocommand_0',['UndoCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a551d4b1c311d41194e2594d70b573fbf',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['usedarkmode_1',['UseDarkMode',['../classFileSurfer_1_1FileSurferSettings.html#abd19198530478937dfd92d04621da834',1,'FileSurfer::FileSurferSettings']]]
];
