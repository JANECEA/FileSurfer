var searchData=
[
  ['undocommand_0',['UndoCommand',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a551d4b1c311d41194e2594d70b573fbf',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['usedarkmode_1',['UseDarkMode',['../class_file_surfer_1_1_file_surfer_settings.html#abd19198530478937dfd92d04621da834',1,'FileSurfer::FileSurferSettings']]]
];
