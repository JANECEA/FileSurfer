var searchData=
[
  ['pathcolumn_0',['PathColumn',['../classFileSurfer_1_1Models_1_1WindowsFileRestorer.html#a55cd037364bedb8152547c139f4540ba',1,'FileSurfer::Models::WindowsFileRestorer']]],
  ['pathtoentry_1',['PathToEntry',['../classFileSurfer_1_1FileSystemEntry.html#a1412300dfcd381a4eb999db9dc1376b7',1,'FileSurfer::FileSystemEntry']]],
  ['previous_2',['Previous',['../classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html#aa8ef1cceb311033d52e67ad2412ac997',1,'FileSurfer::Models::UndoRedoHandler::UndoRedoNode']]]
];
