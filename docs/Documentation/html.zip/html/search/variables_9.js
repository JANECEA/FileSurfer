var searchData=
[
  ['namecolumn_0',['NameColumn',['../class_file_surfer_1_1_models_1_1_windows_file_restorer.html#a01ad5c793bab4a6faebd13a1e7f5b876',1,'FileSurfer::Models::WindowsFileRestorer']]],
  ['newdirname_1',['NewDirName',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a975c8ed8ede7f0b7fb1d9a8cff357a3e',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['newfilename_2',['NewFileName',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a997040005c31a24b5771c6c5d949e62a',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['newimagename_3',['NewImageName',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#afca9f47bf4de25be110735882db190cf',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['nshow_4',['nShow',['../struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#ac28e4faef1113a97588b69783321abeb',1,'FileSurfer::Models::WindowsFileProperties::SHELLEXECUTEINFO']]]
];
