var searchData=
[
  ['addentries_0',['AddEntries',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a6a32b2cc6fe3f55661ab787099e70121',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['addnewnode_1',['AddNewNode',['../classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a6333768d7bad71ae8a3b2d39ffccbfcc',1,'FileSurfer::Models::UndoRedoHandler']]],
  ['addtoarchive_2',['AddToArchive',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#ab89a6de90379cd9cfefe2b2a1d43903c',1,'FileSurfer.ViewModels.MainWindowViewModel.AddToArchive()'],['../classFileSurfer_1_1Views_1_1MainWindow.html#a7d44bc681d04f47c4a2266447936ff6e',1,'FileSurfer.Views.MainWindow.AddToArchive()']]],
  ['addtoquickaccess_3',['AddToQuickAccess',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#aa038ed65c9b51ee1e6e6d5f12dc99089',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['allowimagepastingfromclipboard_4',['AllowImagePastingFromClipboard',['../classFileSurfer_1_1FileSurferSettings.html#a7cac5a15f10697f1b616d449c91ad7d8',1,'FileSurfer::FileSurferSettings']]],
  ['and_20interfaces_5',['Namespaces, Classes, and Interfaces',['../index.html#autotoc_md2',1,'']]],
  ['app_6',['App',['../classFileSurfer_1_1App.html',1,'FileSurfer']]],
  ['app_2eaxaml_2ecs_7',['App.axaml.cs',['../App_8axaml_8cs.html',1,'']]],
  ['application_8',['Application',['../classApplication.html',1,'']]],
  ['archivemanager_9',['ArchiveManager',['../classFileSurfer_1_1Models_1_1ArchiveManager.html',1,'FileSurfer::Models']]],
  ['archivemanager_2ecs_10',['ArchiveManager.cs',['../ArchiveManager_8cs.html',1,'']]],
  ['automaticrefresh_11',['AutomaticRefresh',['../classFileSurfer_1_1FileSurferSettings.html#a77be00f3ae886380a31579e446a6d516',1,'FileSurfer::FileSurferSettings']]],
  ['automaticrefreshinterval_12',['AutomaticRefreshInterval',['../classFileSurfer_1_1FileSurferSettings.html#a77b4f166728e140e28030c75ef29930a',1,'FileSurfer::FileSurferSettings']]]
];
