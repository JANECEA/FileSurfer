var searchData=
[
  ['addentries_0',['AddEntries',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a6a32b2cc6fe3f55661ab787099e70121',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['addnewnode_1',['AddNewNode',['../class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a6333768d7bad71ae8a3b2d39ffccbfcc',1,'FileSurfer::Models::UndoRedoHandler']]],
  ['addtoarchive_2',['AddToArchive',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a4b1fb3a1c06c07bdbf722115b19a5919',1,'FileSurfer.ViewModels.MainWindowViewModel.AddToArchive()'],['../class_file_surfer_1_1_views_1_1_main_window.html#a7d44bc681d04f47c4a2266447936ff6e',1,'FileSurfer.Views.MainWindow.AddToArchive()']]],
  ['addtoquickaccess_3',['AddToQuickAccess',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#aa038ed65c9b51ee1e6e6d5f12dc99089',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['allowimagepastingfromclipboard_4',['AllowImagePastingFromClipboard',['../class_file_surfer_1_1_file_surfer_settings.html#a7cac5a15f10697f1b616d449c91ad7d8',1,'FileSurfer::FileSurferSettings']]],
  ['and_20directories_5',['Files and Directories',['../md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html#autotoc_md2',1,'']]],
  ['and_20improvements_6',['Future goals and improvements',['../md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html#autotoc_md5',1,'']]],
  ['and_20interfaces_7',['Classes and interfaces',['../md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html#autotoc_md3',1,'']]],
  ['app_8',['App',['../class_file_surfer_1_1_app.html',1,'FileSurfer']]],
  ['app_2eaxaml_2ecs_9',['App.axaml.cs',['../_app_8axaml_8cs.html',1,'']]],
  ['archivemanager_10',['ArchiveManager',['../class_file_surfer_1_1_models_1_1_archive_manager.html',1,'FileSurfer::Models']]],
  ['archivemanager_2ecs_11',['ArchiveManager.cs',['../_archive_manager_8cs.html',1,'']]],
  ['arraysearchthreshold_12',['ArraySearchThreshold',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a53be7b0b32ae607613a327b462458b3f',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['automaticrefresh_13',['AutomaticRefresh',['../class_file_surfer_1_1_file_surfer_settings.html#a77be00f3ae886380a31579e446a6d516',1,'FileSurfer::FileSurferSettings']]],
  ['automaticrefreshinterval_14',['AutomaticRefreshInterval',['../class_file_surfer_1_1_file_surfer_settings.html#a77b4f166728e140e28030c75ef29930a',1,'FileSurfer::FileSurferSettings']]]
];
