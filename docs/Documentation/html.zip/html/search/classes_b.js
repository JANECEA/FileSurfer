var searchData=
[
  ['shellexecuteinfo_0',['ShellExecuteInfo',['../structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html',1,'FileSurfer::Models::WindowsFileProperties']]]
];
