var searchData=
[
  ['binfolderid_0',['BinFolderID',['../class_file_surfer_1_1_models_1_1_windows_file_restorer.html#a65092f9484e9511fa70085532cff4ac7',1,'FileSurfer::Models::WindowsFileRestorer']]]
];
