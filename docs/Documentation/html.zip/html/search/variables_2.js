var searchData=
[
  ['cbsize_0',['cbSize',['../structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a304b89097c2083fe51bafe596f9afb85',1,'FileSurfer::Models::WindowsFileProperties::ShellExecuteInfo']]]
];
