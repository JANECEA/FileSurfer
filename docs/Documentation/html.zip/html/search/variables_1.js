var searchData=
[
  ['binfolderid_0',['BinFolderID',['../classFileSurfer_1_1Models_1_1WindowsFileRestorer.html#a65092f9484e9511fa70085532cff4ac7',1,'FileSurfer::Models::WindowsFileRestorer']]],
  ['byteunits_1',['ByteUnits',['../classFileSurfer_1_1FileSystemEntry.html#a3fa85d8099554197865096f8b1f03456',1,'FileSurfer::FileSystemEntry']]]
];
