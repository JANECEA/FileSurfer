var searchData=
[
  ['addentries_0',['AddEntries',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a6a32b2cc6fe3f55661ab787099e70121',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['addnewnode_1',['AddNewNode',['../classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a6333768d7bad71ae8a3b2d39ffccbfcc',1,'FileSurfer::Models::UndoRedoHandler']]],
  ['addtoarchive_2',['AddToArchive',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#ab89a6de90379cd9cfefe2b2a1d43903c',1,'FileSurfer.ViewModels.MainWindowViewModel.AddToArchive()'],['../classFileSurfer_1_1Views_1_1MainWindow.html#a7d44bc681d04f47c4a2266447936ff6e',1,'FileSurfer.Views.MainWindow.AddToArchive()']]],
  ['addtoquickaccess_3',['AddToQuickAccess',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#aa038ed65c9b51ee1e6e6d5f12dc99089',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
