var searchData=
[
  ['addentries_0',['AddEntries',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a6a32b2cc6fe3f55661ab787099e70121',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['addnewnode_1',['AddNewNode',['../class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a6333768d7bad71ae8a3b2d39ffccbfcc',1,'FileSurfer::Models::UndoRedoHandler']]],
  ['addtoarchive_2',['AddToArchive',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a4b1fb3a1c06c07bdbf722115b19a5919',1,'FileSurfer.ViewModels.MainWindowViewModel.AddToArchive()'],['../class_file_surfer_1_1_views_1_1_main_window.html#a7d44bc681d04f47c4a2266447936ff6e',1,'FileSurfer.Views.MainWindow.AddToArchive()']]],
  ['addtoquickaccess_3',['AddToQuickAccess',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#aa038ed65c9b51ee1e6e6d5f12dc99089',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
