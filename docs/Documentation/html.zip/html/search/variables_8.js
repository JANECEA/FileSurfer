var searchData=
[
  ['namecolumn_0',['NameColumn',['../classFileSurfer_1_1Models_1_1WindowsFileRestorer.html#a01ad5c793bab4a6faebd13a1e7f5b876',1,'FileSurfer::Models::WindowsFileRestorer']]],
  ['newdirname_1',['NewDirName',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a975c8ed8ede7f0b7fb1d9a8cff357a3e',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['newfilename_2',['NewFileName',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a997040005c31a24b5771c6c5d949e62a',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['newimagename_3',['NewImageName',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#afca9f47bf4de25be110735882db190cf',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['next_4',['Next',['../classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html#a5581c8a78fd57822617c50753e9fbf90',1,'FileSurfer::Models::UndoRedoHandler::UndoRedoNode']]],
  ['nshow_5',['nShow',['../structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a8e775de74652f05f9c930b40fdce3288',1,'FileSurfer::Models::WindowsFileProperties::ShellExecuteInfo']]]
];
