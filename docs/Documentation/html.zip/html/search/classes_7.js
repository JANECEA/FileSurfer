var searchData=
[
  ['mainwindow_0',['MainWindow',['../classFileSurfer_1_1Views_1_1MainWindow.html',1,'FileSurfer::Views']]],
  ['mainwindowviewmodel_1',['MainWindowViewModel',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html',1,'FileSurfer::ViewModels']]],
  ['movefilesto_2',['MoveFilesTo',['../classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesTo.html',1,'FileSurfer::Models::UndoableFileOperations']]],
  ['movefilestotrash_3',['MoveFilesToTrash',['../classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash.html',1,'FileSurfer::Models::UndoableFileOperations']]]
];
