var searchData=
[
  ['versioncontrolled_0',['VersionControlled',['../class_file_surfer_1_1_file_system_entry.html#a5d66e445dc683854a54b4d2c9d58d7dc',1,'FileSurfer::FileSystemEntry']]]
];
