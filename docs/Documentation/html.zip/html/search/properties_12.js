var searchData=
[
  ['versioncontrolled_0',['VersionControlled',['../classFileSurfer_1_1FileSystemEntry.html#a5d66e445dc683854a54b4d2c9d58d7dc',1,'FileSurfer::FileSystemEntry']]]
];
