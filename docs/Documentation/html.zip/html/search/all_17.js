var searchData=
[
  ['zipfiles_0',['ZipFiles',['../classFileSurfer_1_1Models_1_1ArchiveManager.html#a434f88237644ae0795fc14089a752c15',1,'FileSurfer::Models::ArchiveManager']]],
  ['zipfileswrapperasync_1',['ZipFilesWrapperAsync',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a24a7657845353d4df09e0b28bace09ab',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
