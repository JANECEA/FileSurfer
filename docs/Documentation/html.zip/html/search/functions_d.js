var searchData=
[
  ['paste_0',['Paste',['../classFileSurfer_1_1Models_1_1ClipboardManager.html#ab454334c86273d29c0e72e0e0f0eec99',1,'FileSurfer.Models.ClipboardManager.Paste()'],['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a85db53191b994db578a250f0c75d9487',1,'FileSurfer.ViewModels.MainWindowViewModel.Paste()']]],
  ['pastefromosclipboard_1',['PasteFromOSClipboard',['../classFileSurfer_1_1Models_1_1ClipboardManager.html#ab43cd36ab2bc7aa55b19af6ec1a2a6b3',1,'FileSurfer::Models::ClipboardManager']]],
  ['pintoquickaccess_2',['PinToQuickAccess',['../classFileSurfer_1_1Views_1_1MainWindow.html#aa503d33d9b518eca4f0deaacebc42b95',1,'FileSurfer::Views::MainWindow']]],
  ['pull_3',['Pull',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#acf454a1553b97ca11c3dc8f3563ec80e',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['push_4',['Push',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a6e408a9273a97668f16c575d3fded882',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
