var searchData=
[
  ['vcstatus_0',['VCStatus',['../namespaceFileSurfer_1_1Models.html#ae3f244098519fa62bfa9be2c071da92b',1,'FileSurfer::Models']]]
];
