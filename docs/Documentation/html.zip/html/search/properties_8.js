var searchData=
[
  ['lastmodified_0',['LastModified',['../classFileSurfer_1_1FileSystemEntry.html#a44209706ff33f6fb23aea7cddc26ed77',1,'FileSurfer::FileSystemEntry']]],
  ['lastmodtime_1',['LastModTime',['../classFileSurfer_1_1FileSystemEntry.html#a172515131dfedad3f4edb92913e1afc3',1,'FileSurfer::FileSystemEntry']]]
];
