var searchData=
[
  ['windowsfileiohandler_2ecs_0',['WindowsFileIOHandler.cs',['../WindowsFileIOHandler_8cs.html',1,'']]],
  ['windowsfilerestorer_2ecs_1',['WindowsFileRestorer.cs',['../WindowsFileRestorer_8cs.html',1,'']]],
  ['windowsshellhandler_2ecs_2',['WindowsShellHandler.cs',['../WindowsShellHandler_8cs.html',1,'']]]
];
