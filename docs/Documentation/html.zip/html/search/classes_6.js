var searchData=
[
  ['idatatemplate_0',['IDataTemplate',['../classIDataTemplate.html',1,'']]],
  ['idisposable_1',['IDisposable',['../classIDisposable.html',1,'']]],
  ['ifileiohandler_2',['IFileIOHandler',['../interfaceFileSurfer_1_1Models_1_1IFileIOHandler.html',1,'FileSurfer::Models']]],
  ['iundoablefileoperation_3',['IUndoableFileOperation',['../interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation.html',1,'FileSurfer::Models::UndoableFileOperations']]],
  ['iversioncontrol_4',['IVersionControl',['../interfaceFileSurfer_1_1Models_1_1IVersionControl.html',1,'FileSurfer::Models']]]
];
