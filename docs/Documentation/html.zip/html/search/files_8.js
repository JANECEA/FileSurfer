var searchData=
[
  ['technicalspecification_2emd_0',['TechnicalSpecification.md',['../TechnicalSpecification_8md.html',1,'']]]
];
