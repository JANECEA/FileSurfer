var searchData=
[
  ['hicon_0',['hIcon',['../structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#acd5b2ec6e037698dacd589d1b7e8954e',1,'FileSurfer::Models::WindowsFileProperties::ShellExecuteInfo']]],
  ['hinstapp_1',['hInstApp',['../structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a6a330bfec27f3add42710e71a75202bd',1,'FileSurfer::Models::WindowsFileProperties::ShellExecuteInfo']]],
  ['hkeyclass_2',['hkeyClass',['../structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a227d843d7bb560cdfd765dcc6aa727ed',1,'FileSurfer::Models::WindowsFileProperties::ShellExecuteInfo']]],
  ['hprocess_3',['hProcess',['../structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a7656f7d513466cdaf5cf005ca93419d1',1,'FileSurfer::Models::WindowsFileProperties::ShellExecuteInfo']]],
  ['hwnd_4',['hwnd',['../structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#ae54102729699c9b6937a4de6528c03e0',1,'FileSurfer::Models::WindowsFileProperties::ShellExecuteInfo']]]
];
