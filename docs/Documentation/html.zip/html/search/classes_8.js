var searchData=
[
  ['newdirat_0',['NewDirAt',['../class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_dir_at.html',1,'FileSurfer::Models::UndoableFileOperations']]],
  ['newfileat_1',['NewFileAt',['../class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_file_at.html',1,'FileSurfer::Models::UndoableFileOperations']]]
];
