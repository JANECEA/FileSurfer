var searchData=
[
  ['newdirat_0',['NewDirAt',['../classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewDirAt.html',1,'FileSurfer::Models::UndoableFileOperations']]],
  ['newfileat_1',['NewFileAt',['../classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html',1,'FileSurfer::Models::UndoableFileOperations']]]
];
