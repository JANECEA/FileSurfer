var searchData=
[
  ['movetotrashcommand_0',['MoveToTrashCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a2a5a5a56de046d6ff2bcbb76ac804007',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
