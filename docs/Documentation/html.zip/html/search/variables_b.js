var searchData=
[
  ['searchinglabel_0',['SearchingLabel',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a8b820f99b7f2a994e92c9bf14742d01f',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['serializeroptions_1',['SerializerOptions',['../classFileSurfer_1_1FileSurferSettings.html#a92db266615c802912b7056c6cd9fa118',1,'FileSurfer::FileSurferSettings']]],
  ['settingsfiledir_2',['SettingsFileDir',['../classFileSurfer_1_1FileSurferSettings.html#a416cddb1ed48cdb5bbe793e855cb4e0c',1,'FileSurfer::FileSurferSettings']]],
  ['settingsfilepath_3',['SettingsFilePath',['../classFileSurfer_1_1FileSurferSettings.html#a84a6be061519bb4548bf3e32672746a0',1,'FileSurfer::FileSurferSettings']]],
  ['showdialoglimitb_4',['ShowDialogLimitB',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a9de28fc4c8c2d8b35227f810d66ed97a',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['sizelimit_5',['SizeLimit',['../classFileSurfer_1_1FileSystemEntry.html#a40c49a8341cce3f91e026118c1bf25f7',1,'FileSurfer::FileSystemEntry']]]
];
