var searchData=
[
  ['build_0',['Build',['../class_file_surfer_1_1_view_locator.html#a9fff45e1c4bc9e4d55de8ef18086d72a',1,'FileSurfer::ViewLocator']]],
  ['buildavaloniaapp_1',['BuildAvaloniaApp',['../class_file_surfer_1_1_program.html#a0476e14fde032df06d8e38bc5368c6b3',1,'FileSurfer::Program']]]
];
