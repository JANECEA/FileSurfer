var searchData=
[
  ['build_0',['Build',['../classFileSurfer_1_1ViewLocator.html#a9fff45e1c4bc9e4d55de8ef18086d72a',1,'FileSurfer::ViewLocator']]],
  ['buildavaloniaapp_1',['BuildAvaloniaApp',['../classFileSurfer_1_1Program.html#a0476e14fde032df06d8e38bc5368c6b3',1,'FileSurfer::Program']]]
];
