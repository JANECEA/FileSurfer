var searchData=
[
  ['app_0',['App',['../classFileSurfer_1_1App.html',1,'FileSurfer']]],
  ['application_1',['Application',['../classApplication.html',1,'']]],
  ['archivemanager_2',['ArchiveManager',['../classFileSurfer_1_1Models_1_1ArchiveManager.html',1,'FileSurfer::Models']]]
];
