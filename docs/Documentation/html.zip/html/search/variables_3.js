var searchData=
[
  ['data_0',['Data',['../classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html#a6aed9b27d60dd7139e58ef06a11cecfb',1,'FileSurfer::Models::UndoRedoHandler::UndoRedoNode']]],
  ['driveicon_1',['DriveIcon',['../classFileSurfer_1_1FileSystemEntry.html#aa07567ebf4eb38e844ea6dc1816df578',1,'FileSurfer::FileSystemEntry']]],
  ['dwhotkey_2',['dwHotKey',['../structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a2f35d5575517f85bd229ce8b9f9b711b',1,'FileSurfer::Models::WindowsFileProperties::ShellExecuteInfo']]]
];
