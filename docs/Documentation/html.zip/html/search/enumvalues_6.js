var searchData=
[
  ['unstaged_0',['Unstaged',['../namespaceFileSurfer_1_1Models.html#ae3f244098519fa62bfa9be2c071da92bad9c90a7d6a180b805c17ef41e4154095',1,'FileSurfer::Models']]]
];
