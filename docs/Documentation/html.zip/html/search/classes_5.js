var searchData=
[
  ['gitversioncontrolhandler_0',['GitVersionControlHandler',['../classFileSurfer_1_1Models_1_1GitVersionControlHandler.html',1,'FileSurfer::Models']]]
];
