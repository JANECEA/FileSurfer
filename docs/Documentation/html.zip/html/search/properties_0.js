var searchData=
[
  ['allowimagepastingfromclipboard_0',['AllowImagePastingFromClipboard',['../classFileSurfer_1_1FileSurferSettings.html#a7cac5a15f10697f1b616d449c91ad7d8',1,'FileSurfer::FileSurferSettings']]],
  ['automaticrefresh_1',['AutomaticRefresh',['../classFileSurfer_1_1FileSurferSettings.html#a77be00f3ae886380a31579e446a6d516',1,'FileSurfer::FileSurferSettings']]],
  ['automaticrefreshinterval_2',['AutomaticRefreshInterval',['../classFileSurfer_1_1FileSurferSettings.html#a77b4f166728e140e28030c75ef29930a',1,'FileSurfer::FileSurferSettings']]]
];
