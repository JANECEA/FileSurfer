var searchData=
[
  ['paste_0',['Paste',['../classFileSurfer_1_1Models_1_1ClipboardManager.html#ab454334c86273d29c0e72e0e0f0eec99',1,'FileSurfer.Models.ClipboardManager.Paste()'],['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a85db53191b994db578a250f0c75d9487',1,'FileSurfer.ViewModels.MainWindowViewModel.Paste()']]],
  ['pastecommand_1',['PasteCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a415bd6ea0ba1f10393d6edc1c8e3cd4c',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['pastefromosclipboard_2',['PasteFromOSClipboard',['../classFileSurfer_1_1Models_1_1ClipboardManager.html#ab43cd36ab2bc7aa55b19af6ec1a2a6b3',1,'FileSurfer::Models::ClipboardManager']]],
  ['pathcolumn_3',['PathColumn',['../classFileSurfer_1_1Models_1_1WindowsFileRestorer.html#a55cd037364bedb8152547c139f4540ba',1,'FileSurfer::Models::WindowsFileRestorer']]],
  ['pathtoentry_4',['PathToEntry',['../classFileSurfer_1_1FileSystemEntry.html#a1412300dfcd381a4eb999db9dc1376b7',1,'FileSurfer::FileSystemEntry']]],
  ['pintoquickaccess_5',['PinToQuickAccess',['../classFileSurfer_1_1Views_1_1MainWindow.html#aa503d33d9b518eca4f0deaacebc42b95',1,'FileSurfer::Views::MainWindow']]],
  ['previous_6',['Previous',['../classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html#aa8ef1cceb311033d52e67ad2412ac997',1,'FileSurfer::Models::UndoRedoHandler::UndoRedoNode']]],
  ['program_7',['Program',['../classFileSurfer_1_1Program.html',1,'FileSurfer']]],
  ['program_2ecs_8',['Program.cs',['../Program_8cs.html',1,'']]],
  ['pull_9',['Pull',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#acf454a1553b97ca11c3dc8f3563ec80e',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['pullcommand_10',['PullCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a509c68f3e4034d34a03969a3af60e38d',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['push_11',['Push',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a6e408a9273a97668f16c575d3fded882',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['pushcommand_12',['PushCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#aaac2cf9c0cbee5dbdf1a8aea8de94afb',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
