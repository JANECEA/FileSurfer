var searchData=
[
  ['paste_0',['Paste',['../class_file_surfer_1_1_models_1_1_clipboard_manager.html#ab454334c86273d29c0e72e0e0f0eec99',1,'FileSurfer.Models.ClipboardManager.Paste()'],['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a85db53191b994db578a250f0c75d9487',1,'FileSurfer.ViewModels.MainWindowViewModel.Paste()']]],
  ['pastecommand_1',['PasteCommand',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a415bd6ea0ba1f10393d6edc1c8e3cd4c',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['pastefromosclipboard_2',['PasteFromOSClipboard',['../class_file_surfer_1_1_models_1_1_clipboard_manager.html#ab43cd36ab2bc7aa55b19af6ec1a2a6b3',1,'FileSurfer::Models::ClipboardManager']]],
  ['pathcolumn_3',['PathColumn',['../class_file_surfer_1_1_models_1_1_windows_file_restorer.html#a55cd037364bedb8152547c139f4540ba',1,'FileSurfer::Models::WindowsFileRestorer']]],
  ['pathtoentry_4',['PathToEntry',['../class_file_surfer_1_1_file_system_entry.html#a1412300dfcd381a4eb999db9dc1376b7',1,'FileSurfer::FileSystemEntry']]],
  ['pintoquickaccess_5',['PinToQuickAccess',['../class_file_surfer_1_1_views_1_1_main_window.html#aa503d33d9b518eca4f0deaacebc42b95',1,'FileSurfer::Views::MainWindow']]],
  ['program_6',['Program',['../class_file_surfer_1_1_program.html',1,'FileSurfer']]],
  ['program_2ecs_7',['Program.cs',['../_program_8cs.html',1,'']]],
  ['project_20overview_8',['FileSurfer - Project Overview',['../md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html',1,'']]],
  ['project_20structure_9',['Project Structure',['../md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html#autotoc_md1',1,'']]],
  ['projectoverview_2emd_10',['ProjectOverview.md',['../_project_overview_8md.html',1,'']]],
  ['pull_11',['Pull',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#acf454a1553b97ca11c3dc8f3563ec80e',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['pullcommand_12',['PullCommand',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a509c68f3e4034d34a03969a3af60e38d',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['push_13',['Push',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a6e408a9273a97668f16c575d3fded882',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['pushcommand_14',['PushCommand',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#aaac2cf9c0cbee5dbdf1a8aea8de94afb',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
