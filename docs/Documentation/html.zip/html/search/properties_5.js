var searchData=
[
  ['fileentries_0',['FileEntries',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#af311b4260cd446a8ff9260935b41375c',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['filesizedisplaylimit_1',['FileSizeDisplayLimit',['../class_file_surfer_1_1_file_surfer_settings.html#aada112364b1d0f59160f81f8319397c1',1,'FileSurfer::FileSurferSettings']]]
];
