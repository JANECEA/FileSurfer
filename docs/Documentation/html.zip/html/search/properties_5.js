var searchData=
[
  ['fileentries_0',['FileEntries',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#af311b4260cd446a8ff9260935b41375c',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['filesizedisplaylimit_1',['FileSizeDisplayLimit',['../classFileSurfer_1_1FileSurferSettings.html#aada112364b1d0f59160f81f8319397c1',1,'FileSurfer::FileSurferSettings']]]
];
