var searchData=
[
  ['clipboardmanager_0',['ClipboardManager',['../class_file_surfer_1_1_models_1_1_clipboard_manager.html',1,'FileSurfer::Models']]],
  ['copyfilesto_1',['CopyFilesTo',['../class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html',1,'FileSurfer::Models::UndoableFileOperations']]]
];
