var searchData=
[
  ['clipboardmanager_0',['ClipboardManager',['../classFileSurfer_1_1Models_1_1ClipboardManager.html',1,'FileSurfer::Models']]],
  ['copyfilesto_1',['CopyFilesTo',['../classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html',1,'FileSurfer::Models::UndoableFileOperations']]]
];
