var searchData=
[
  ['iconview_0',['IconView',['../classFileSurfer_1_1Views_1_1MainWindow.html#ab6d6367e0d50e87702cbe522222e352f',1,'FileSurfer::Views::MainWindow']]],
  ['initialize_1',['Initialize',['../classFileSurfer_1_1App.html#af33900614cedc8cb8666f6e97a473256',1,'FileSurfer::App']]],
  ['inputboxlostfocus_2',['InputBoxLostFocus',['../classFileSurfer_1_1Views_1_1MainWindow.html#ade08449226b494da79a07e17e264264b',1,'FileSurfer::Views::MainWindow']]],
  ['invertselection_3',['InvertSelection',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a44bd70c6685c403b55c3d3bda103f942',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['isduplicateoperation_4',['IsDuplicateOperation',['../classFileSurfer_1_1Models_1_1ClipboardManager.html#afc3e36ca6252996438bdf75e1858f518',1,'FileSurfer::Models::ClipboardManager']]],
  ['ishead_5',['IsHead',['../classFileSurfer_1_1Models_1_1UndoRedoHandler.html#afc2afeeaaa5dad66b8e9abdd2b399309',1,'FileSurfer::Models::UndoRedoHandler']]],
  ['ishidden_6',['IsHidden',['../interfaceFileSurfer_1_1Models_1_1IFileIOHandler.html#a4e566097b54447053cdc984ce96fec7c',1,'FileSurfer.Models.IFileIOHandler.IsHidden()'],['../classFileSurfer_1_1Models_1_1WindowsFileIOHandler.html#aaadb3644e573d8d51cd5ba399b2a5c40',1,'FileSurfer.Models.WindowsFileIOHandler.IsHidden()']]],
  ['islinkedtodirectory_7',['IsLinkedToDirectory',['../interfaceFileSurfer_1_1Models_1_1IFileIOHandler.html#ae860baad60b412eccbfa405c8fd951ee',1,'FileSurfer.Models.IFileIOHandler.IsLinkedToDirectory()'],['../classFileSurfer_1_1Models_1_1WindowsFileIOHandler.html#a73760e97368ab1185bfc092606f39a6b',1,'FileSurfer.Models.WindowsFileIOHandler.IsLinkedToDirectory(string linkPath, out string? directory)']]],
  ['isosprotected_8',['IsOSProtected',['../classFileSurfer_1_1Models_1_1WindowsFileIOHandler.html#a6a7e1c4d26453a21b146173c6e8d11e7',1,'FileSurfer::Models::WindowsFileIOHandler']]],
  ['istail_9',['IsTail',['../classFileSurfer_1_1Models_1_1UndoRedoHandler.html#aa289dca6e1d312a9454c0d176cb50b2e',1,'FileSurfer::Models::UndoRedoHandler']]],
  ['isvaliddirectory_10',['IsValidDirectory',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a4c938190544f3ff139f8572f439ac17f',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['isvaliddirname_11',['IsValidDirName',['../classFileSurfer_1_1Models_1_1WindowsFileIOHandler.html#a9d6c91ae66fc836016444558a7bb8fa9',1,'FileSurfer::Models::WindowsFileIOHandler']]],
  ['isvalidfilename_12',['IsValidFileName',['../classFileSurfer_1_1Models_1_1WindowsFileIOHandler.html#a413bc2fef97847f67558e4b40cea52f3',1,'FileSurfer::Models::WindowsFileIOHandler']]],
  ['isversioncontrolled_13',['IsVersionControlled',['../interfaceFileSurfer_1_1Models_1_1IVersionControl.html#a3b7c713fe5bd831ddd0993b8dde32d9d',1,'FileSurfer.Models.IVersionControl.IsVersionControlled()'],['../classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a25744e9a755cb6c3ba4b03dd148e074c',1,'FileSurfer.Models.GitVersionControlHandler.IsVersionControlled()']]],
  ['iszipped_14',['IsZipped',['../classFileSurfer_1_1Models_1_1ArchiveManager.html#aac02e678b0f26cd439c832ffee6d0d2e',1,'FileSurfer::Models::ArchiveManager']]]
];
