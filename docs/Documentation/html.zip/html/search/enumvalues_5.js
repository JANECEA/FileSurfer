var searchData=
[
  ['type_0',['Type',['../namespaceFileSurfer.html#a7d93fd9e0886998da504a63742727e69aa1fa27779242b4902f7ae3bdd5c6d508',1,'FileSurfer']]]
];
