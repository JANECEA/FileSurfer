var searchData=
[
  ['mainwindow_2eaxaml_2ecs_0',['MainWindow.axaml.cs',['../MainWindow_8axaml_8cs.html',1,'']]],
  ['mainwindowviewmodel_2ecs_1',['MainWindowViewModel.cs',['../MainWindowViewModel_8cs.html',1,'']]]
];
