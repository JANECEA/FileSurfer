var searchData=
[
  ['name_0',['Name',['../classFileSurfer_1_1FileSystemEntry.html#a8397a09af104d3616690bb9d2ae8b398',1,'FileSurfer::FileSystemEntry']]],
  ['newdircommand_1',['NewDirCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a580b58332ea9cd9b7de30c608de00ef3',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['newdirectoryname_2',['NewDirectoryName',['../classFileSurfer_1_1FileSurferSettings.html#a7a2c88bd8019bc1f0f196307e66a71e0',1,'FileSurfer::FileSurferSettings']]],
  ['newfilecommand_3',['NewFileCommand',['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a0474d9fa63a78db12db82ffa126d761c',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['newfilename_4',['NewFileName',['../classFileSurfer_1_1FileSurferSettings.html#aafbd27eb83280f0a2c1daa72e22f5973',1,'FileSurfer::FileSurferSettings']]],
  ['newimagename_5',['NewImageName',['../classFileSurfer_1_1FileSurferSettings.html#abd74b9455c80ebeb17e3e20415d79562',1,'FileSurfer::FileSurferSettings']]],
  ['notepadapp_6',['NotePadApp',['../classFileSurfer_1_1FileSurferSettings.html#a7bca420bb2267b5a68f39df9a8879884',1,'FileSurfer::FileSurferSettings']]]
];
