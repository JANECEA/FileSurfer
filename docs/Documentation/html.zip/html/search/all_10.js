var searchData=
[
  ['quickaccess_0',['QuickAccess',['../classFileSurfer_1_1FileSurferSettings.html#a139fd701a2800cf90444d92000e3183d',1,'FileSurfer.FileSurferSettings.QuickAccess'],['../classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html#a1f021102435e2faf3e3f8aa101862721',1,'FileSurfer.ViewModels.MainWindowViewModel.QuickAccess']]]
];
