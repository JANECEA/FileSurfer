var searchData=
[
  ['bitmap_0',['Bitmap',['../FileSystemEntry_8cs.html#a43ced1cda6840fdc326fbc42aa835b2e',1,'FileSystemEntry.cs']]]
];
