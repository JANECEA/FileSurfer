var searchData=
[
  ['specification_0',['Technical specification',['../index.html',1,'']]]
];
