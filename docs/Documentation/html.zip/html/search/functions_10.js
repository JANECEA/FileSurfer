var searchData=
[
  ['textboxgotfocus_0',['TextBoxGotFocus',['../class_file_surfer_1_1_views_1_1_main_window.html#a41a6210ac1843892f37c377ff67a31af',1,'FileSurfer::Views::MainWindow']]],
  ['textboxlostfocus_1',['TextBoxLostFocus',['../class_file_surfer_1_1_views_1_1_main_window.html#a09c541f327acd453630915d44caa44af',1,'FileSurfer::Views::MainWindow']]]
];
