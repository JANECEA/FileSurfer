var searchData=
[
  ['textboxgotfocus_0',['TextBoxGotFocus',['../classFileSurfer_1_1Views_1_1MainWindow.html#a41a6210ac1843892f37c377ff67a31af',1,'FileSurfer::Views::MainWindow']]],
  ['textboxlostfocus_1',['TextBoxLostFocus',['../classFileSurfer_1_1Views_1_1MainWindow.html#a09c541f327acd453630915d44caa44af',1,'FileSurfer::Views::MainWindow']]]
];
