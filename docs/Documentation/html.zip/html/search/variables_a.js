var searchData=
[
  ['restoreverb_0',['RestoreVerb',['../classFileSurfer_1_1Models_1_1WindowsFileRestorer.html#ac9f60985469bb913cd19c3f92d077f0d',1,'FileSurfer::Models::WindowsFileRestorer']]]
];
