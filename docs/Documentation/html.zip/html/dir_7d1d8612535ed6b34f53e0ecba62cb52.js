var dir_7d1d8612535ed6b34f53e0ecba62cb52 =
[
    [ "ArchiveManager.cs", "ArchiveManager_8cs.html", "ArchiveManager_8cs" ],
    [ "ClipboardManager.cs", "ClipboardManager_8cs.html", "ClipboardManager_8cs" ],
    [ "FileNameGenerator.cs", "FileNameGenerator_8cs.html", "FileNameGenerator_8cs" ],
    [ "GitVersionControlHandler.cs", "GitVersionControlHandler_8cs.html", "GitVersionControlHandler_8cs" ],
    [ "UndoableFileOperations.cs", "UndoableFileOperations_8cs.html", "UndoableFileOperations_8cs" ],
    [ "UndoRedoHandler.cs", "UndoRedoHandler_8cs.html", "UndoRedoHandler_8cs" ],
    [ "WindowsFileIOHandler.cs", "WindowsFileIOHandler_8cs.html", "WindowsFileIOHandler_8cs" ],
    [ "WindowsFileRestorer.cs", "WindowsFileRestorer_8cs.html", "WindowsFileRestorer_8cs" ],
    [ "WindowsShellHandler.cs", "WindowsShellHandler_8cs.html", "WindowsShellHandler_8cs" ]
];