var dir_7d1d8612535ed6b34f53e0ecba62cb52 =
[
    [ "ArchiveManager.cs", "_archive_manager_8cs.html", "_archive_manager_8cs" ],
    [ "ClipboardManager.cs", "_clipboard_manager_8cs.html", "_clipboard_manager_8cs" ],
    [ "FileNameGenerator.cs", "_file_name_generator_8cs.html", "_file_name_generator_8cs" ],
    [ "GitVersionControlHandler.cs", "_git_version_control_handler_8cs.html", "_git_version_control_handler_8cs" ],
    [ "UndoableFileOperations.cs", "_undoable_file_operations_8cs.html", "_undoable_file_operations_8cs" ],
    [ "UndoRedoHandler.cs", "_undo_redo_handler_8cs.html", "_undo_redo_handler_8cs" ],
    [ "WindowsFileIOHandler.cs", "_windows_file_i_o_handler_8cs.html", "_windows_file_i_o_handler_8cs" ],
    [ "WindowsFileRestorer.cs", "_windows_file_restorer_8cs.html", "_windows_file_restorer_8cs" ],
    [ "WindowsShellHandler.cs", "_windows_shell_handler_8cs.html", "_windows_shell_handler_8cs" ]
];