var _windows_shell_handler_8cs =
[
    [ "FileSurfer.Models.WindowsFileProperties", "class_file_surfer_1_1_models_1_1_windows_file_properties.html", "class_file_surfer_1_1_models_1_1_windows_file_properties" ],
    [ "FileSurfer.Models.WindowsFileProperties.SHELLEXECUTEINFO", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o" ]
];