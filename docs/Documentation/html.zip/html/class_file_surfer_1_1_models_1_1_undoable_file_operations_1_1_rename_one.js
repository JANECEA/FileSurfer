var class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one =
[
    [ "RenameOne", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html#aaa47fe1b7aeabcc0623be072ecb015b0", null ],
    [ "Redo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html#a5005213c1d4827b0b151ae198442006a", null ],
    [ "Undo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html#a0aac590db188a2bfd054cb6251743ed8", null ],
    [ "_entry", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html#a23f11f1df16170998c55b31bdce7c327", null ],
    [ "_fileIOHandler", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html#aab9e3d6c38b5132e5ac1ae289f8e8d3e", null ],
    [ "_newName", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html#a14d0766c86604f1bc07d6686895e8637", null ],
    [ "_newPath", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html#aaa6040ef1e4c0414dd22f7f980fc9b3f", null ]
];