var _archive_manager_8cs =
[
    [ "FileSurfer.Models.ArchiveManager", "class_file_surfer_1_1_models_1_1_archive_manager.html", "class_file_surfer_1_1_models_1_1_archive_manager" ]
];