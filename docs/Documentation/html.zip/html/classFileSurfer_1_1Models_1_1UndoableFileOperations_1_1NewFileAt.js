var classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt =
[
    [ "NewFileAt", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html#aa0012ec7cd4657cf74c60eced4c04191", null ],
    [ "Redo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html#a07ac452254dc7b066b07e91b0124906e", null ],
    [ "Undo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html#afc513d9b4acffb7c44aabe6a866954c8", null ],
    [ "_fileIOHandler", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html#aa700eb2c3af57c705a63a7a9ebc5d0f1", null ],
    [ "_fileName", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html#a2a4f868eba39a504dff82b9611becd11", null ],
    [ "_path", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html#accf0795f9ed87d8b0f787d102769fc84", null ]
];