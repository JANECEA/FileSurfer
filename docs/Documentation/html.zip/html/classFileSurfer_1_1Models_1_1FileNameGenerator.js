var classFileSurfer_1_1Models_1_1FileNameGenerator =
[
    [ "CanBeRenamedCollectively", "classFileSurfer_1_1Models_1_1FileNameGenerator.html#a9418e2bf14d3aaeb29aa77f2ffc48da5", null ],
    [ "GetAvailableName", "classFileSurfer_1_1Models_1_1FileNameGenerator.html#ab34efef01ff90608030fc26f1c0290aa", null ],
    [ "GetAvailableNames", "classFileSurfer_1_1Models_1_1FileNameGenerator.html#a7e5c7cfb027b3cbc145aec92eaaf0900", null ],
    [ "GetCopyName", "classFileSurfer_1_1Models_1_1FileNameGenerator.html#a5f35b45425c9201e3deb68520c1ad0f0", null ]
];