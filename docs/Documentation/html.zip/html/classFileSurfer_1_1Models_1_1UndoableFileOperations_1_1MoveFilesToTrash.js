var classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash =
[
    [ "MoveFilesToTrash", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash.html#ad151d05edf65df2eb2b46395dee1a0a0", null ],
    [ "Redo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash.html#a419308b829ea5c93c52b89c1606026d9", null ],
    [ "Undo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash.html#aeebe27456f773c57cba0cd000a87c8d7", null ],
    [ "_entries", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash.html#aa9b8e6996e3d3bed96c2df7e6001399d", null ],
    [ "_fileIOHandler", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash.html#a1477d28fb0cf15d6bad742d7942716bc", null ]
];