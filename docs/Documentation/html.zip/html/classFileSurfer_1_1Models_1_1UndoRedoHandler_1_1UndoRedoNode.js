var classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode =
[
    [ "UndoRedoNode", "classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html#a4581b39ea2c57b33dd0ca7ddcacc1536", null ],
    [ "Data", "classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html#a6aed9b27d60dd7139e58ef06a11cecfb", null ],
    [ "Next", "classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html#a5581c8a78fd57822617c50753e9fbf90", null ],
    [ "Previous", "classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html#aa8ef1cceb311033d52e67ad2412ac997", null ]
];