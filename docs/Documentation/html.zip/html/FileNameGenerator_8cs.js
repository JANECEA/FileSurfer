var FileNameGenerator_8cs =
[
    [ "FileSurfer.Models.FileNameGenerator", "classFileSurfer_1_1Models_1_1FileNameGenerator.html", "classFileSurfer_1_1Models_1_1FileNameGenerator" ]
];