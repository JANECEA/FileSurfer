var classFileSurfer_1_1Models_1_1UndoRedoHandler =
[
    [ "UndoRedoNode", "classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html", "classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode" ],
    [ "UndoRedoHandler", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a729e28486e6382ee83eb64aed02ade46", null ],
    [ "AddNewNode", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a6333768d7bad71ae8a3b2d39ffccbfcc", null ],
    [ "GetNext", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a402290ac3db4ef1ed7ce22300d6578ac", null ],
    [ "GetPrevious", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#aecef0f37e363ba36310ad61c0978c6c9", null ],
    [ "IsHead", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#afc2afeeaaa5dad66b8e9abdd2b399309", null ],
    [ "IsTail", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#aa289dca6e1d312a9454c0d176cb50b2e", null ],
    [ "MoveToNext", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a349a2e7ac51f0f3b46e83aeaefa8abd5", null ],
    [ "MoveToPrevious", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a2df4aabdded2febbbfee29350637fbb3", null ],
    [ "RemoveNode", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a168d284f070c3fc7685320e9a1ecbdb9", null ],
    [ "_current", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a92c12b1f190ea22dd5d3a15a805d7cfd", null ],
    [ "_head", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#afc4cb36a0c594dca475b1296861eadf0", null ],
    [ "_tail", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a180ba59c9fe368e7480d8f051e548394", null ],
    [ "Current", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html#a18e4c18db6c30fe9fb56c69862f76e2d", null ]
];