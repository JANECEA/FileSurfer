var interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation =
[
    [ "Redo", "interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation.html#a53882a4d1ea2b7291d5e5eb7e639f65a", null ],
    [ "Undo", "interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation.html#a7e00b4b016950bacceda39c5fac58657", null ]
];