var classFileSurfer_1_1Models_1_1ClipboardManager =
[
    [ "ClipboardManager", "classFileSurfer_1_1Models_1_1ClipboardManager.html#a5cbb7f4d9a66d17fa0dc7afdcfdd79a4", null ],
    [ "ClearClipboard", "classFileSurfer_1_1Models_1_1ClipboardManager.html#a107cbd91ea430498815188105b9a6ccf", null ],
    [ "CompareClipboards", "classFileSurfer_1_1Models_1_1ClipboardManager.html#a5667cbb47030a6792d1e99d4087d188c", null ],
    [ "Copy", "classFileSurfer_1_1Models_1_1ClipboardManager.html#ab645666820bfe795ed7a78aec35d5537", null ],
    [ "CopyPathToFile", "classFileSurfer_1_1Models_1_1ClipboardManager.html#a48abcb135b3599404b093bb1e9159be1", null ],
    [ "CopyToOSClipboard", "classFileSurfer_1_1Models_1_1ClipboardManager.html#ab7faddf24c752635fd8857a48ffaff27", null ],
    [ "Cut", "classFileSurfer_1_1Models_1_1ClipboardManager.html#ae7d2df8004e7cb03498a30debc4572a5", null ],
    [ "Duplicate", "classFileSurfer_1_1Models_1_1ClipboardManager.html#ac16b59edc2d8048bd17564a186a056ea", null ],
    [ "GetClipboard", "classFileSurfer_1_1Models_1_1ClipboardManager.html#a356edd6870ed930221b8a8d8c9b86cc1", null ],
    [ "IsDuplicateOperation", "classFileSurfer_1_1Models_1_1ClipboardManager.html#afc3e36ca6252996438bdf75e1858f518", null ],
    [ "Paste", "classFileSurfer_1_1Models_1_1ClipboardManager.html#ab454334c86273d29c0e72e0e0f0eec99", null ],
    [ "PasteFromOSClipboard", "classFileSurfer_1_1Models_1_1ClipboardManager.html#ab43cd36ab2bc7aa55b19af6ec1a2a6b3", null ],
    [ "SaveImageToPath", "classFileSurfer_1_1Models_1_1ClipboardManager.html#add1b0985b886622d7e2444b8ed3d6258", null ],
    [ "_copyFromDir", "classFileSurfer_1_1Models_1_1ClipboardManager.html#ad8004d85d4570a07734a3ac90291b1b2", null ],
    [ "_fileIOHandler", "classFileSurfer_1_1Models_1_1ClipboardManager.html#ab228b49c790aec504f4280373bf89cc7", null ],
    [ "_newImageName", "classFileSurfer_1_1Models_1_1ClipboardManager.html#a4c7e087179a7f0490bc0ffbc0393be38", null ],
    [ "_programClipboard", "classFileSurfer_1_1Models_1_1ClipboardManager.html#ad8a5be4332c6dba1fa99d5bbc25c71bf", null ],
    [ "IsCutOperation", "classFileSurfer_1_1Models_1_1ClipboardManager.html#adcce936d4ab1ec3cb9a62d821f5409fe", null ]
];