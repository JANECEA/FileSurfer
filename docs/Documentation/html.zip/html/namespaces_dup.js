var namespaces_dup =
[
    [ "FileSurfer", "namespaceFileSurfer.html", "namespaceFileSurfer" ]
];