var namespaceFileSurfer =
[
    [ "Models", "namespaceFileSurfer_1_1Models.html", "namespaceFileSurfer_1_1Models" ],
    [ "ViewModels", "namespaceFileSurfer_1_1ViewModels.html", "namespaceFileSurfer_1_1ViewModels" ],
    [ "Views", "namespaceFileSurfer_1_1Views.html", "namespaceFileSurfer_1_1Views" ],
    [ "App", "classFileSurfer_1_1App.html", "classFileSurfer_1_1App" ],
    [ "FileSurferSettings", "classFileSurfer_1_1FileSurferSettings.html", "classFileSurfer_1_1FileSurferSettings" ],
    [ "FileSystemEntry", "classFileSurfer_1_1FileSystemEntry.html", "classFileSurfer_1_1FileSystemEntry" ],
    [ "Program", "classFileSurfer_1_1Program.html", "classFileSurfer_1_1Program" ],
    [ "ViewLocator", "classFileSurfer_1_1ViewLocator.html", "classFileSurfer_1_1ViewLocator" ],
    [ "DisplayModeEnum", "namespaceFileSurfer.html#add75a44e500cbc07ebc69ace0726976e", [
      [ "ListView", "namespaceFileSurfer.html#add75a44e500cbc07ebc69ace0726976ea416c421e722428b4f6e0863f98a25cff", null ],
      [ "IconView", "namespaceFileSurfer.html#add75a44e500cbc07ebc69ace0726976eac689f85d431a8db0da40fceda311eeec", null ]
    ] ],
    [ "SortBy", "namespaceFileSurfer.html#a7d93fd9e0886998da504a63742727e69", [
      [ "Name", "namespaceFileSurfer.html#a7d93fd9e0886998da504a63742727e69a49ee3087348e8d44e1feda1917443987", null ],
      [ "Date", "namespaceFileSurfer.html#a7d93fd9e0886998da504a63742727e69a44749712dbec183e983dcd78a7736c41", null ],
      [ "Type", "namespaceFileSurfer.html#a7d93fd9e0886998da504a63742727e69aa1fa27779242b4902f7ae3bdd5c6d508", null ],
      [ "Size", "namespaceFileSurfer.html#a7d93fd9e0886998da504a63742727e69a6f6cb72d544962fa333e2e34ce64f719", null ]
    ] ]
];