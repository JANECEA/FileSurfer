var MainWindowViewModel_8cs =
[
    [ "FileSurfer.ViewModels.MainWindowViewModel", "classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html", "classFileSurfer_1_1ViewModels_1_1MainWindowViewModel" ]
];