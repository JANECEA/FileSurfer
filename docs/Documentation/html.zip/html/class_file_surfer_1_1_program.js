var class_file_surfer_1_1_program =
[
    [ "BuildAvaloniaApp", "class_file_surfer_1_1_program.html#a0476e14fde032df06d8e38bc5368c6b3", null ],
    [ "Main", "class_file_surfer_1_1_program.html#aaa7ecaca4f625faccbc2e825b99ca809", null ]
];