var namespaceFileSurfer_1_1ViewModels =
[
    [ "MainWindowViewModel", "classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html", "classFileSurfer_1_1ViewModels_1_1MainWindowViewModel" ]
];