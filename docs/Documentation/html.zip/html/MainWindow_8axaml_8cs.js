var MainWindow_8axaml_8cs =
[
    [ "FileSurfer.Views.MainWindow", "classFileSurfer_1_1Views_1_1MainWindow.html", "classFileSurfer_1_1Views_1_1MainWindow" ]
];