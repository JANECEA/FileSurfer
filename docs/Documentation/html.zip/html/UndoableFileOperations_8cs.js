var UndoableFileOperations_8cs =
[
    [ "FileSurfer.Models.UndoableFileOperations.MoveFilesToTrash", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash" ],
    [ "FileSurfer.Models.UndoableFileOperations.MoveFilesTo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesTo.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesTo" ],
    [ "FileSurfer.Models.UndoableFileOperations.CopyFilesTo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo" ],
    [ "FileSurfer.Models.UndoableFileOperations.DuplicateFiles", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1DuplicateFiles.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1DuplicateFiles" ],
    [ "FileSurfer.Models.UndoableFileOperations.RenameMultiple", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple" ],
    [ "FileSurfer.Models.UndoableFileOperations.RenameOne", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameOne.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameOne" ],
    [ "FileSurfer.Models.UndoableFileOperations.NewFileAt", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt" ],
    [ "FileSurfer.Models.UndoableFileOperations.NewDirAt", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewDirAt.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewDirAt" ]
];