var classFileSurfer_1_1App =
[
    [ "Initialize", "classFileSurfer_1_1App.html#af33900614cedc8cb8666f6e97a473256", null ],
    [ "OnFrameworkInitializationCompleted", "classFileSurfer_1_1App.html#a34ba10ee4460d1e596aaecfa95ad7cf3", null ]
];