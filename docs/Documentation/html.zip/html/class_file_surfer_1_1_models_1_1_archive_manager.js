var class_file_surfer_1_1_models_1_1_archive_manager =
[
    [ "IsZipped", "class_file_surfer_1_1_models_1_1_archive_manager.html#aac02e678b0f26cd439c832ffee6d0d2e", null ],
    [ "UnzipArchive", "class_file_surfer_1_1_models_1_1_archive_manager.html#afb5fafefc29c1cc61264300bc8c56321", null ],
    [ "ZipFiles", "class_file_surfer_1_1_models_1_1_archive_manager.html#a7b6683b08a2cd1a5dc059ce3502d6c8c", null ]
];