var dir_5626a86c095640f395b2e856d5963952 =
[
    [ "IFileIOHandler.cs", "IFileIOHandler_8cs.html", "IFileIOHandler_8cs" ],
    [ "IUndoableFileOperation.cs", "IUndoableFileOperation_8cs.html", "IUndoableFileOperation_8cs" ],
    [ "IVersionControl.cs", "IVersionControl_8cs.html", "IVersionControl_8cs" ]
];