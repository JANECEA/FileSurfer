var dir_5626a86c095640f395b2e856d5963952 =
[
    [ "IFileIOHandler.cs", "_i_file_i_o_handler_8cs.html", "_i_file_i_o_handler_8cs" ],
    [ "IUndoableFileOperation.cs", "_i_undoable_file_operation_8cs.html", "_i_undoable_file_operation_8cs" ],
    [ "IVersionControl.cs", "_i_version_control_8cs.html", "_i_version_control_8cs" ]
];