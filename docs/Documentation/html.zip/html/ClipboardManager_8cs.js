var ClipboardManager_8cs =
[
    [ "FileSurfer.Models.ClipboardManager", "classFileSurfer_1_1Models_1_1ClipboardManager.html", "classFileSurfer_1_1Models_1_1ClipboardManager" ]
];