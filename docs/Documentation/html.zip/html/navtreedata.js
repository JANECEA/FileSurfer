/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "FileSurfer", "index.html", [
    [ "FileSurfer - Project Overview", "md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html", [
      [ "Project Structure", "md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html#autotoc_md1", [
        [ "Files and Directories", "md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html#autotoc_md2", null ]
      ] ],
      [ "Classes and interfaces", "md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html#autotoc_md3", null ],
      [ "Namespaces", "md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html#autotoc_md4", null ],
      [ "Future goals and improvements", "md__d_1_2_m_a_t_f_y_z_22024__letni_22024__letni__code_2_programovani__2_2_git_lab_2student-janecea_2docs_2_project_overview.html#autotoc_md5", null ]
    ] ],
    [ "Packages", "namespaces.html", [
      [ "Package List", "namespaces.html", "namespaces_dup" ],
      [ "Package Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Properties", "functions_prop.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Typedefs", "globals_type.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_app_8axaml_8cs.html",
"class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a402290ac3db4ef1ed7ce22300d6578ac",
"class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a0445bfbd66860564cae1df1f088cc68a",
"class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#aee9172ba80e7ac97a30458834fc000c1",
"interface_file_surfer_1_1_models_1_1_i_file_i_o_handler.html#ad8b41aac6be57b924413c5c78c4ebc68"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';