var ArchiveManager_8cs =
[
    [ "FileSurfer.Models.ArchiveManager", "classFileSurfer_1_1Models_1_1ArchiveManager.html", "classFileSurfer_1_1Models_1_1ArchiveManager" ]
];