var files_dup =
[
    [ "docs", "dir_49e56c817e5e54854c35e136979f97ca.html", null ],
    [ "FileSurfer", "dir_9a910ec909ac6a1225ab0744c22119f3.html", "dir_9a910ec909ac6a1225ab0744c22119f3" ]
];