var classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo =
[
    [ "CopyFilesTo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html#a2399c0c5f94361a40cee388c73fea29a", null ],
    [ "Redo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html#a6ce802bcf2542a0b1341a0c5abb554e2", null ],
    [ "Undo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html#a02b33b443728dd33b00bb6876bc0aa8b", null ],
    [ "_destinationDir", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html#ad94f91a09f81254f3120190cdd415177", null ],
    [ "_entries", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html#a834adff1c3b8041b1c54154e211f13d0", null ],
    [ "_fileIOHandler", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html#a6f5510768fec9088119d0280fcc4cd81", null ]
];