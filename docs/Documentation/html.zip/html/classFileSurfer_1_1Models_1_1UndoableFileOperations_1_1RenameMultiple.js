var classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple =
[
    [ "RenameMultiple", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html#a9753dc0ff82d582efd5e105f22364ffc", null ],
    [ "Redo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html#ad633c5e0fa9d5f32c590a2159000e011", null ],
    [ "Undo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html#af61a956a4082f1be4853a871c8d6e03f", null ],
    [ "_dirName", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html#a7c86da9ccfe557ba6df8df04602c4d5d", null ],
    [ "_entries", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html#aee24edf08194df02c612a772bc378c6e", null ],
    [ "_fileIOHandler", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html#a91720201eacbef4ddba65bf2c3373e2e", null ],
    [ "_newNames", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html#ab8ed71c604ca68952529c712fbb3e608", null ]
];