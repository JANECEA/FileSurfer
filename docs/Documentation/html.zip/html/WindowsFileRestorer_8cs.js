var WindowsFileRestorer_8cs =
[
    [ "FileSurfer.Models.WindowsFileRestorer", "classFileSurfer_1_1Models_1_1WindowsFileRestorer.html", "classFileSurfer_1_1Models_1_1WindowsFileRestorer" ]
];