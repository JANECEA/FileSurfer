var class_file_surfer_1_1_view_locator =
[
    [ "Build", "class_file_surfer_1_1_view_locator.html#a9fff45e1c4bc9e4d55de8ef18086d72a", null ],
    [ "Match", "class_file_surfer_1_1_view_locator.html#ade684288452ebd4182f4d823f6fb138d", null ]
];