var class_file_surfer_1_1_app =
[
    [ "Initialize", "class_file_surfer_1_1_app.html#af33900614cedc8cb8666f6e97a473256", null ],
    [ "OnFrameworkInitializationCompleted", "class_file_surfer_1_1_app.html#a34ba10ee4460d1e596aaecfa95ad7cf3", null ]
];