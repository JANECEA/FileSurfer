var class_file_surfer_1_1_models_1_1_clipboard_manager =
[
    [ "ClipboardManager", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#a5cbb7f4d9a66d17fa0dc7afdcfdd79a4", null ],
    [ "ClearClipboar", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#a7c3ca291d573f09a3ab96c3267655df8", null ],
    [ "Copy", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#ab645666820bfe795ed7a78aec35d5537", null ],
    [ "CopyPathToFile", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#a48abcb135b3599404b093bb1e9159be1", null ],
    [ "CopyToOSClipboard", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#ab7faddf24c752635fd8857a48ffaff27", null ],
    [ "Cut", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#ae7d2df8004e7cb03498a30debc4572a5", null ],
    [ "Duplicate", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#ac16b59edc2d8048bd17564a186a056ea", null ],
    [ "GetClipboard", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#a356edd6870ed930221b8a8d8c9b86cc1", null ],
    [ "IsDuplicateOperation", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#afc3e36ca6252996438bdf75e1858f518", null ],
    [ "Paste", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#ab454334c86273d29c0e72e0e0f0eec99", null ],
    [ "PasteFromOSClipboard", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#ab43cd36ab2bc7aa55b19af6ec1a2a6b3", null ],
    [ "SaveImageToPath", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#add1b0985b886622d7e2444b8ed3d6258", null ],
    [ "_copyFromDir", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#ad8004d85d4570a07734a3ac90291b1b2", null ],
    [ "_fileIOHandler", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#ab228b49c790aec504f4280373bf89cc7", null ],
    [ "_newImageName", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#a4c7e087179a7f0490bc0ffbc0393be38", null ],
    [ "_programClipboard", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#ad8a5be4332c6dba1fa99d5bbc25c71bf", null ],
    [ "IsCutOperation", "class_file_surfer_1_1_models_1_1_clipboard_manager.html#adcce936d4ab1ec3cb9a62d821f5409fe", null ]
];