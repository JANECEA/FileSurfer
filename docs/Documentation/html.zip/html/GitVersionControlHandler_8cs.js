var GitVersionControlHandler_8cs =
[
    [ "FileSurfer.Models.GitVersionControlHandler", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html", "classFileSurfer_1_1Models_1_1GitVersionControlHandler" ],
    [ "VCStatus", "GitVersionControlHandler_8cs.html#ae3f244098519fa62bfa9be2c071da92b", [
      [ "NotVersionControlled", "GitVersionControlHandler_8cs.html#ae3f244098519fa62bfa9be2c071da92bac26158fd1d189f902f25e986b13c0ce0", null ],
      [ "Staged", "GitVersionControlHandler_8cs.html#ae3f244098519fa62bfa9be2c071da92ba44bc04de5a94daecaffe9c26f7746988", null ],
      [ "Unstaged", "GitVersionControlHandler_8cs.html#ae3f244098519fa62bfa9be2c071da92bad9c90a7d6a180b805c17ef41e4154095", null ]
    ] ]
];