var namespaceFileSurfer_1_1Views =
[
    [ "ErrorWindow", "classFileSurfer_1_1Views_1_1ErrorWindow.html", "classFileSurfer_1_1Views_1_1ErrorWindow" ],
    [ "MainWindow", "classFileSurfer_1_1Views_1_1MainWindow.html", "classFileSurfer_1_1Views_1_1MainWindow" ]
];