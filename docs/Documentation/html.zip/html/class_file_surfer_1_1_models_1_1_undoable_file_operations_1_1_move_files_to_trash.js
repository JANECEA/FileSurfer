var class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash =
[
    [ "MoveFilesToTrash", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash.html#ad151d05edf65df2eb2b46395dee1a0a0", null ],
    [ "Redo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash.html#a419308b829ea5c93c52b89c1606026d9", null ],
    [ "Undo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash.html#aeebe27456f773c57cba0cd000a87c8d7", null ],
    [ "_entries", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash.html#aa9b8e6996e3d3bed96c2df7e6001399d", null ],
    [ "_fileIOHandler", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash.html#a1477d28fb0cf15d6bad742d7942716bc", null ]
];