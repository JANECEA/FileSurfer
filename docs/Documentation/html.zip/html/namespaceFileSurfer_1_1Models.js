var namespaceFileSurfer_1_1Models =
[
    [ "UndoableFileOperations", "namespaceFileSurfer_1_1Models_1_1UndoableFileOperations.html", "namespaceFileSurfer_1_1Models_1_1UndoableFileOperations" ],
    [ "ArchiveManager", "classFileSurfer_1_1Models_1_1ArchiveManager.html", "classFileSurfer_1_1Models_1_1ArchiveManager" ],
    [ "ClipboardManager", "classFileSurfer_1_1Models_1_1ClipboardManager.html", "classFileSurfer_1_1Models_1_1ClipboardManager" ],
    [ "FileNameGenerator", "classFileSurfer_1_1Models_1_1FileNameGenerator.html", "classFileSurfer_1_1Models_1_1FileNameGenerator" ],
    [ "GitVersionControlHandler", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html", "classFileSurfer_1_1Models_1_1GitVersionControlHandler" ],
    [ "IFileIOHandler", "interfaceFileSurfer_1_1Models_1_1IFileIOHandler.html", "interfaceFileSurfer_1_1Models_1_1IFileIOHandler" ],
    [ "IVersionControl", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html", "interfaceFileSurfer_1_1Models_1_1IVersionControl" ],
    [ "UndoRedoHandler", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html", "classFileSurfer_1_1Models_1_1UndoRedoHandler" ],
    [ "WindowsFileIOHandler", "classFileSurfer_1_1Models_1_1WindowsFileIOHandler.html", "classFileSurfer_1_1Models_1_1WindowsFileIOHandler" ],
    [ "WindowsFileProperties", "classFileSurfer_1_1Models_1_1WindowsFileProperties.html", "classFileSurfer_1_1Models_1_1WindowsFileProperties" ],
    [ "WindowsFileRestorer", "classFileSurfer_1_1Models_1_1WindowsFileRestorer.html", "classFileSurfer_1_1Models_1_1WindowsFileRestorer" ],
    [ "VCStatus", "namespaceFileSurfer_1_1Models.html#ae3f244098519fa62bfa9be2c071da92b", [
      [ "NotVersionControlled", "namespaceFileSurfer_1_1Models.html#ae3f244098519fa62bfa9be2c071da92bac26158fd1d189f902f25e986b13c0ce0", null ],
      [ "Staged", "namespaceFileSurfer_1_1Models.html#ae3f244098519fa62bfa9be2c071da92ba44bc04de5a94daecaffe9c26f7746988", null ],
      [ "Unstaged", "namespaceFileSurfer_1_1Models.html#ae3f244098519fa62bfa9be2c071da92bad9c90a7d6a180b805c17ef41e4154095", null ]
    ] ]
];