var namespace_file_surfer_1_1_models_1_1_undoable_file_operations =
[
    [ "CopyFilesTo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to" ],
    [ "DuplicateFiles", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files" ],
    [ "IUndoableFileOperation", "interface_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_i_undoable_file_operation.html", "interface_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_i_undoable_file_operation" ],
    [ "MoveFilesTo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to" ],
    [ "MoveFilesToTrash", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash" ],
    [ "NewDirAt", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_dir_at.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_dir_at" ],
    [ "NewFileAt", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_file_at.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_file_at" ],
    [ "RenameMultiple", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_multiple.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_multiple" ],
    [ "RenameOne", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one" ]
];