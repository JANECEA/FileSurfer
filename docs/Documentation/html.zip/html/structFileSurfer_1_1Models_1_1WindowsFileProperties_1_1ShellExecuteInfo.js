var structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo =
[
    [ "cbSize", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a304b89097c2083fe51bafe596f9afb85", null ],
    [ "dwHotKey", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a2f35d5575517f85bd229ce8b9f9b711b", null ],
    [ "fMask", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a7d06d15b81af683ce35b5e6c12a50f0b", null ],
    [ "hIcon", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#acd5b2ec6e037698dacd589d1b7e8954e", null ],
    [ "hInstApp", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a6a330bfec27f3add42710e71a75202bd", null ],
    [ "hkeyClass", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a227d843d7bb560cdfd765dcc6aa727ed", null ],
    [ "hProcess", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a7656f7d513466cdaf5cf005ca93419d1", null ],
    [ "hwnd", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#ae54102729699c9b6937a4de6528c03e0", null ],
    [ "lpClass", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a94435fd1edde83cd3554405bb244ef7a", null ],
    [ "lpDirectory", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a53c46d3dcce8addd3e51c63195081eca", null ],
    [ "lpFile", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#aca2fd47f9846fe8c2eb2dea1ff01f2d5", null ],
    [ "lpIDList", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#aaeb28b9a95efc7f8250ee065e6c594cc", null ],
    [ "lpParameters", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#ad67bbecb68bbf848f6aa5406a7180dfb", null ],
    [ "lpVerb", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a2c6f89d7119ddd21d241f6a4d6ffa397", null ],
    [ "nShow", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html#a8e775de74652f05f9c930b40fdce3288", null ]
];