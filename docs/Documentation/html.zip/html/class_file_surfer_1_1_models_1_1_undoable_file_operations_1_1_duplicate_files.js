var class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files =
[
    [ "DuplicateFiles", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html#ae885e48c6c2d7e8379937a342c669510", null ],
    [ "Redo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html#a0747f3cb79d1b9d1d884194c8f83a75a", null ],
    [ "Undo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html#ac85f7dbb3dd436557fc4ee622d5ec5c3", null ],
    [ "_copyNames", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html#a5459b1355f0216a862fd0d55f2936336", null ],
    [ "_entries", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html#a35a1cc8b7fe592079eade5a0025c041a", null ],
    [ "_fileIOHandler", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html#ad119948e824304b4f993493b580cabdb", null ],
    [ "_parentDir", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html#acb49b6c62f35e699d16f8dce397c5316", null ]
];