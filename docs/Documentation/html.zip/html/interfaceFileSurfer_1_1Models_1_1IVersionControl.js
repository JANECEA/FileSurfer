var interfaceFileSurfer_1_1Models_1_1IVersionControl =
[
    [ "CommitChanges", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html#afb9b709d9af61d6622bf726742764b5f", null ],
    [ "ConsolidateStatus", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html#a13db52e3d67fdd01483fb4e75849d317", null ],
    [ "DownloadChanges", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html#abc780dfd96c7e9a632547aaf418fb3db", null ],
    [ "GetBranches", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html#ad68a79ec5ef88a0a56ba49ae1eb7590a", null ],
    [ "GetCurrentBranchName", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html#ae12a0b0df34cc6b0af2934e8f15f00d0", null ],
    [ "IsVersionControlled", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html#a3b7c713fe5bd831ddd0993b8dde32d9d", null ],
    [ "StageChange", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html#add2249de02b5154666d32b40e84baed8", null ],
    [ "SwitchBranches", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html#a1af25a0348ba0449f200566448049cd4", null ],
    [ "UnstageChange", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html#a74db356e0e8d989c712d91620a9fcde5", null ],
    [ "UploadChanges", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html#af5c761659d848948a5de4be27c6a9cc7", null ]
];