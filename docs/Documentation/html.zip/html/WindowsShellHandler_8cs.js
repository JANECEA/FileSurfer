var WindowsShellHandler_8cs =
[
    [ "FileSurfer.Models.WindowsFileProperties", "classFileSurfer_1_1Models_1_1WindowsFileProperties.html", "classFileSurfer_1_1Models_1_1WindowsFileProperties" ],
    [ "FileSurfer.Models.WindowsFileProperties.ShellExecuteInfo", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo" ]
];