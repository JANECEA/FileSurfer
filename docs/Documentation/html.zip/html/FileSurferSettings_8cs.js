var FileSurferSettings_8cs =
[
    [ "FileSurfer.FileSurferSettings", "classFileSurfer_1_1FileSurferSettings.html", "classFileSurfer_1_1FileSurferSettings" ],
    [ "DisplayModeEnum", "FileSurferSettings_8cs.html#add75a44e500cbc07ebc69ace0726976e", [
      [ "ListView", "FileSurferSettings_8cs.html#add75a44e500cbc07ebc69ace0726976ea416c421e722428b4f6e0863f98a25cff", null ],
      [ "IconView", "FileSurferSettings_8cs.html#add75a44e500cbc07ebc69ace0726976eac689f85d431a8db0da40fceda311eeec", null ]
    ] ],
    [ "SortBy", "FileSurferSettings_8cs.html#a7d93fd9e0886998da504a63742727e69", [
      [ "Name", "FileSurferSettings_8cs.html#a7d93fd9e0886998da504a63742727e69a49ee3087348e8d44e1feda1917443987", null ],
      [ "Date", "FileSurferSettings_8cs.html#a7d93fd9e0886998da504a63742727e69a44749712dbec183e983dcd78a7736c41", null ],
      [ "Type", "FileSurferSettings_8cs.html#a7d93fd9e0886998da504a63742727e69aa1fa27779242b4902f7ae3bdd5c6d508", null ],
      [ "Size", "FileSurferSettings_8cs.html#a7d93fd9e0886998da504a63742727e69a6f6cb72d544962fa333e2e34ce64f719", null ]
    ] ]
];