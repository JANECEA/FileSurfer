var classFileSurfer_1_1Models_1_1GitVersionControlHandler =
[
    [ "GitVersionControlHandler", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a4d0f45c39a4f4678c00cb6f76d2380fb", null ],
    [ "CommitChanges", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#ae9c2995af4e9a28367f9a5e84eeda998", null ],
    [ "ConsolidateStatus", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a22fdd066414ba5cd2ad4aea2bd702512", null ],
    [ "ConvertToVCStatus", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#ab110275371b3a83a3f6a3613e2a76908", null ],
    [ "Dispose", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#afe047b4c604c2123e3c307abd823c2d4", null ],
    [ "DownloadChanges", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#aab2ce51d78e6c54658bafc600ed75276", null ],
    [ "GetBranches", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#abe12e7240b968e24efa9a7cd6f0b77ba", null ],
    [ "GetCurrentBranchName", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a3914a62685b5477d7a5977448ba0bb64", null ],
    [ "GetWorkingDir", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#aff8491933d98d6649792025797db21c7", null ],
    [ "IsVersionControlled", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a25744e9a755cb6c3ba4b03dd148e074c", null ],
    [ "SetFileStates", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a8fbaa155d9fcae851c6fb8acaad40236", null ],
    [ "StageChange", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a959564d432fbaefeeb6469b6a5f20618", null ],
    [ "SwitchBranches", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a7bfbce5f680eb08686afa8d2d467d7f4", null ],
    [ "UnstageChange", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#af752574976267d05d05c879eab5f8ccc", null ],
    [ "UploadChanges", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a406442d981f15e6af1a003569fe5f555", null ],
    [ "_currentRepo", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#adab5decfdef445097c453df9abe3f41c", null ],
    [ "_fileIOHandler", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a76142e78896871eca3601abb1fec1311", null ],
    [ "_statusDict", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a44a3bfd99a5bcb3300b19472da8d4c78", null ],
    [ "MissingRepoMessage", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html#a97dc33df11ed92013631ab84a78e8cb1", null ]
];