var classFileSurfer_1_1Models_1_1WindowsFileProperties =
[
    [ "ShellExecuteInfo", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo" ],
    [ "ShellExecuteEx", "classFileSurfer_1_1Models_1_1WindowsFileProperties.html#a24ec5d9df4ba87637ab1b8755db06c82", null ],
    [ "ShowFileProperties", "classFileSurfer_1_1Models_1_1WindowsFileProperties.html#afe61e139ae84e6f7a650b78fbadcf4ac", null ],
    [ "ShowOpenAsDialog", "classFileSurfer_1_1Models_1_1WindowsFileProperties.html#a5651910ae6e64deb7e20280a7c68b6d1", null ]
];