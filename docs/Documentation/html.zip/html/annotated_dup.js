var annotated_dup =
[
    [ "FileSurfer", "namespaceFileSurfer.html", [
      [ "Models", "namespaceFileSurfer_1_1Models.html", [
        [ "UndoableFileOperations", "namespaceFileSurfer_1_1Models_1_1UndoableFileOperations.html", [
          [ "CopyFilesTo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo" ],
          [ "DuplicateFiles", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1DuplicateFiles.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1DuplicateFiles" ],
          [ "IUndoableFileOperation", "interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation.html", "interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation" ],
          [ "MoveFilesTo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesTo.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesTo" ],
          [ "MoveFilesToTrash", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash" ],
          [ "NewDirAt", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewDirAt.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewDirAt" ],
          [ "NewFileAt", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt" ],
          [ "RenameMultiple", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple" ],
          [ "RenameOne", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameOne.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameOne" ]
        ] ],
        [ "ArchiveManager", "classFileSurfer_1_1Models_1_1ArchiveManager.html", "classFileSurfer_1_1Models_1_1ArchiveManager" ],
        [ "ClipboardManager", "classFileSurfer_1_1Models_1_1ClipboardManager.html", "classFileSurfer_1_1Models_1_1ClipboardManager" ],
        [ "FileNameGenerator", "classFileSurfer_1_1Models_1_1FileNameGenerator.html", "classFileSurfer_1_1Models_1_1FileNameGenerator" ],
        [ "GitVersionControlHandler", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html", "classFileSurfer_1_1Models_1_1GitVersionControlHandler" ],
        [ "IFileIOHandler", "interfaceFileSurfer_1_1Models_1_1IFileIOHandler.html", "interfaceFileSurfer_1_1Models_1_1IFileIOHandler" ],
        [ "IVersionControl", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html", "interfaceFileSurfer_1_1Models_1_1IVersionControl" ],
        [ "UndoRedoHandler", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html", "classFileSurfer_1_1Models_1_1UndoRedoHandler" ],
        [ "WindowsFileIOHandler", "classFileSurfer_1_1Models_1_1WindowsFileIOHandler.html", "classFileSurfer_1_1Models_1_1WindowsFileIOHandler" ],
        [ "WindowsFileProperties", "classFileSurfer_1_1Models_1_1WindowsFileProperties.html", "classFileSurfer_1_1Models_1_1WindowsFileProperties" ],
        [ "WindowsFileRestorer", "classFileSurfer_1_1Models_1_1WindowsFileRestorer.html", "classFileSurfer_1_1Models_1_1WindowsFileRestorer" ]
      ] ],
      [ "ViewModels", "namespaceFileSurfer_1_1ViewModels.html", [
        [ "MainWindowViewModel", "classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html", "classFileSurfer_1_1ViewModels_1_1MainWindowViewModel" ]
      ] ],
      [ "Views", "namespaceFileSurfer_1_1Views.html", [
        [ "ErrorWindow", "classFileSurfer_1_1Views_1_1ErrorWindow.html", "classFileSurfer_1_1Views_1_1ErrorWindow" ],
        [ "MainWindow", "classFileSurfer_1_1Views_1_1MainWindow.html", "classFileSurfer_1_1Views_1_1MainWindow" ]
      ] ],
      [ "App", "classFileSurfer_1_1App.html", "classFileSurfer_1_1App" ],
      [ "FileSurferSettings", "classFileSurfer_1_1FileSurferSettings.html", "classFileSurfer_1_1FileSurferSettings" ],
      [ "FileSystemEntry", "classFileSurfer_1_1FileSystemEntry.html", "classFileSurfer_1_1FileSystemEntry" ],
      [ "Program", "classFileSurfer_1_1Program.html", "classFileSurfer_1_1Program" ],
      [ "ViewLocator", "classFileSurfer_1_1ViewLocator.html", "classFileSurfer_1_1ViewLocator" ]
    ] ],
    [ "Application", "classApplication.html", null ],
    [ "IDataTemplate", "classIDataTemplate.html", null ],
    [ "IDisposable", "classIDisposable.html", null ],
    [ "ReactiveObject", "classReactiveObject.html", null ],
    [ "Window", "classWindow.html", null ]
];