var hierarchy =
[
    [ "Application", "classApplication.html", [
      [ "FileSurfer.App", "classFileSurfer_1_1App.html", null ]
    ] ],
    [ "FileSurfer.Models.ArchiveManager", "classFileSurfer_1_1Models_1_1ArchiveManager.html", null ],
    [ "FileSurfer.Models.ClipboardManager", "classFileSurfer_1_1Models_1_1ClipboardManager.html", null ],
    [ "FileSurfer.Models.FileNameGenerator", "classFileSurfer_1_1Models_1_1FileNameGenerator.html", null ],
    [ "FileSurfer.FileSurferSettings", "classFileSurfer_1_1FileSurferSettings.html", null ],
    [ "FileSurfer.FileSystemEntry", "classFileSurfer_1_1FileSystemEntry.html", null ],
    [ "IDataTemplate", "classIDataTemplate.html", [
      [ "FileSurfer.ViewLocator", "classFileSurfer_1_1ViewLocator.html", null ]
    ] ],
    [ "IDisposable", "classIDisposable.html", [
      [ "FileSurfer.Models.IVersionControl", "interfaceFileSurfer_1_1Models_1_1IVersionControl.html", [
        [ "FileSurfer.Models.GitVersionControlHandler", "classFileSurfer_1_1Models_1_1GitVersionControlHandler.html", null ]
      ] ]
    ] ],
    [ "FileSurfer.Models.IFileIOHandler", "interfaceFileSurfer_1_1Models_1_1IFileIOHandler.html", [
      [ "FileSurfer.Models.WindowsFileIOHandler", "classFileSurfer_1_1Models_1_1WindowsFileIOHandler.html", null ]
    ] ],
    [ "FileSurfer.Models.UndoableFileOperations.IUndoableFileOperation", "interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation.html", [
      [ "FileSurfer.Models.UndoableFileOperations.CopyFilesTo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.DuplicateFiles", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1DuplicateFiles.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.MoveFilesTo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesTo.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.MoveFilesToTrash", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.NewDirAt", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewDirAt.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.NewFileAt", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.RenameMultiple", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.RenameOne", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameOne.html", null ]
    ] ],
    [ "FileSurfer.Program", "classFileSurfer_1_1Program.html", null ],
    [ "ReactiveObject", "classReactiveObject.html", [
      [ "FileSurfer.ViewModels.MainWindowViewModel", "classFileSurfer_1_1ViewModels_1_1MainWindowViewModel.html", null ]
    ] ],
    [ "FileSurfer.Models.WindowsFileProperties.ShellExecuteInfo", "structFileSurfer_1_1Models_1_1WindowsFileProperties_1_1ShellExecuteInfo.html", null ],
    [ "FileSurfer.Models.UndoRedoHandler< T >", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html", null ],
    [ "FileSurfer.Models.UndoRedoHandler< IUndoableFileOperation >", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html", null ],
    [ "FileSurfer.Models.UndoRedoHandler< string >", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html", null ],
    [ "FileSurfer.Models.UndoRedoHandler< T >.UndoRedoNode", "classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html", null ],
    [ "Window", "classWindow.html", [
      [ "FileSurfer.Views.ErrorWindow", "classFileSurfer_1_1Views_1_1ErrorWindow.html", null ],
      [ "FileSurfer.Views.MainWindow", "classFileSurfer_1_1Views_1_1MainWindow.html", null ]
    ] ],
    [ "FileSurfer.Models.WindowsFileProperties", "classFileSurfer_1_1Models_1_1WindowsFileProperties.html", null ],
    [ "FileSurfer.Models.WindowsFileRestorer", "classFileSurfer_1_1Models_1_1WindowsFileRestorer.html", null ]
];