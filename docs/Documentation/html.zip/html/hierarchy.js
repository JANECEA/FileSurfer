var hierarchy =
[
    [ "Application", null, [
      [ "FileSurfer.App", "class_file_surfer_1_1_app.html", null ]
    ] ],
    [ "FileSurfer.Models.ArchiveManager", "class_file_surfer_1_1_models_1_1_archive_manager.html", null ],
    [ "FileSurfer.Models.ClipboardManager", "class_file_surfer_1_1_models_1_1_clipboard_manager.html", null ],
    [ "FileSurfer.Models.FileNameGenerator", "class_file_surfer_1_1_models_1_1_file_name_generator.html", null ],
    [ "FileSurfer.FileSurferSettings", "class_file_surfer_1_1_file_surfer_settings.html", null ],
    [ "FileSurfer.FileSystemEntry", "class_file_surfer_1_1_file_system_entry.html", null ],
    [ "IDataTemplate", null, [
      [ "FileSurfer.ViewLocator", "class_file_surfer_1_1_view_locator.html", null ]
    ] ],
    [ "IDisposable", null, [
      [ "FileSurfer.Models.GitVersionControlHandler", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html", null ],
      [ "FileSurfer.Models.IVersionControl", "interface_file_surfer_1_1_models_1_1_i_version_control.html", [
        [ "FileSurfer.Models.GitVersionControlHandler", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html", null ]
      ] ]
    ] ],
    [ "FileSurfer.Models.IFileIOHandler", "interface_file_surfer_1_1_models_1_1_i_file_i_o_handler.html", [
      [ "FileSurfer.Models.WindowsFileIOHandler", "class_file_surfer_1_1_models_1_1_windows_file_i_o_handler.html", null ]
    ] ],
    [ "INotifyPropertyChanged", null, [
      [ "FileSurfer.ViewModels.MainWindowViewModel", "class_file_surfer_1_1_view_models_1_1_main_window_view_model.html", null ]
    ] ],
    [ "FileSurfer.Models.UndoableFileOperations.IUndoableFileOperation", "interface_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_i_undoable_file_operation.html", [
      [ "FileSurfer.Models.UndoableFileOperations.CopyFilesTo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.DuplicateFiles", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.MoveFilesTo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.MoveFilesToTrash", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.NewDirAt", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_dir_at.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.NewFileAt", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_file_at.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.RenameMultiple", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_multiple.html", null ],
      [ "FileSurfer.Models.UndoableFileOperations.RenameOne", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html", null ]
    ] ],
    [ "FileSurfer.Program", "class_file_surfer_1_1_program.html", null ],
    [ "ReactiveObject", null, [
      [ "FileSurfer.ViewModels.MainWindowViewModel", "class_file_surfer_1_1_view_models_1_1_main_window_view_model.html", null ]
    ] ],
    [ "FileSurfer.Models.WindowsFileProperties.SHELLEXECUTEINFO", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html", null ],
    [ "FileSurfer.Models.UndoRedoHandler< T >", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html", null ],
    [ "FileSurfer.Models.UndoRedoHandler< IUndoableFileOperation >", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html", null ],
    [ "FileSurfer.Models.UndoRedoHandler< string >", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html", null ],
    [ "FileSurfer.Models.UndoRedoHandler< T >.UndoRedoNode", "class_file_surfer_1_1_models_1_1_undo_redo_handler_1_1_undo_redo_node.html", null ],
    [ "Window", null, [
      [ "FileSurfer.Views.ErrorWindow", "class_file_surfer_1_1_views_1_1_error_window.html", null ],
      [ "FileSurfer.Views.MainWindow", "class_file_surfer_1_1_views_1_1_main_window.html", null ]
    ] ],
    [ "FileSurfer.Models.WindowsFileProperties", "class_file_surfer_1_1_models_1_1_windows_file_properties.html", null ],
    [ "FileSurfer.Models.WindowsFileRestorer", "class_file_surfer_1_1_models_1_1_windows_file_restorer.html", null ]
];