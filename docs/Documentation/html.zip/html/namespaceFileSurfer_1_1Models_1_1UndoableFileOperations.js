var namespaceFileSurfer_1_1Models_1_1UndoableFileOperations =
[
    [ "CopyFilesTo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1CopyFilesTo" ],
    [ "DuplicateFiles", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1DuplicateFiles.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1DuplicateFiles" ],
    [ "IUndoableFileOperation", "interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation.html", "interfaceFileSurfer_1_1Models_1_1UndoableFileOperations_1_1IUndoableFileOperation" ],
    [ "MoveFilesTo", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesTo.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesTo" ],
    [ "MoveFilesToTrash", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1MoveFilesToTrash" ],
    [ "NewDirAt", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewDirAt.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewDirAt" ],
    [ "NewFileAt", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1NewFileAt" ],
    [ "RenameMultiple", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameMultiple" ],
    [ "RenameOne", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameOne.html", "classFileSurfer_1_1Models_1_1UndoableFileOperations_1_1RenameOne" ]
];