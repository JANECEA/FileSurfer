var UndoRedoHandler_8cs =
[
    [ "FileSurfer.Models.UndoRedoHandler< T >", "classFileSurfer_1_1Models_1_1UndoRedoHandler.html", "classFileSurfer_1_1Models_1_1UndoRedoHandler" ],
    [ "FileSurfer.Models.UndoRedoHandler< T >.UndoRedoNode", "classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode.html", "classFileSurfer_1_1Models_1_1UndoRedoHandler_1_1UndoRedoNode" ]
];