var class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to =
[
    [ "CopyFilesTo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html#a2399c0c5f94361a40cee388c73fea29a", null ],
    [ "Redo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html#a6ce802bcf2542a0b1341a0c5abb554e2", null ],
    [ "Undo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html#a02b33b443728dd33b00bb6876bc0aa8b", null ],
    [ "_destinationDir", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html#ad94f91a09f81254f3120190cdd415177", null ],
    [ "_entries", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html#a834adff1c3b8041b1c54154e211f13d0", null ],
    [ "_fileIOHandler", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html#a6f5510768fec9088119d0280fcc4cd81", null ]
];