var classFileSurfer_1_1Models_1_1ArchiveManager =
[
    [ "IsZipped", "classFileSurfer_1_1Models_1_1ArchiveManager.html#aac02e678b0f26cd439c832ffee6d0d2e", null ],
    [ "UnzipArchive", "classFileSurfer_1_1Models_1_1ArchiveManager.html#afb5fafefc29c1cc61264300bc8c56321", null ],
    [ "ZipFiles", "classFileSurfer_1_1Models_1_1ArchiveManager.html#a434f88237644ae0795fc14089a752c15", null ]
];