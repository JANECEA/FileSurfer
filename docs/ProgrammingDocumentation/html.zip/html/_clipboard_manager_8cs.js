var _clipboard_manager_8cs =
[
    [ "FileSurfer.Models.ClipboardManager", "class_file_surfer_1_1_models_1_1_clipboard_manager.html", "class_file_surfer_1_1_models_1_1_clipboard_manager" ]
];