var searchData=
[
  ['app_0',['App',['../class_file_surfer_1_1_app.html',1,'FileSurfer']]],
  ['archivemanager_1',['ArchiveManager',['../class_file_surfer_1_1_models_1_1_archive_manager.html',1,'FileSurfer::Models']]]
];
