var searchData=
[
  ['quickaccess_0',['QuickAccess',['../class_file_surfer_1_1_file_surfer_settings.html#a139fd701a2800cf90444d92000e3183d',1,'FileSurfer.FileSurferSettings.QuickAccess'],['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a1f021102435e2faf3e3f8aa101862721',1,'FileSurfer.ViewModels.MainWindowViewModel.QuickAccess']]]
];
