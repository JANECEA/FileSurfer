var searchData=
[
  ['paste_0',['Paste',['../class_file_surfer_1_1_models_1_1_clipboard_manager.html#ab454334c86273d29c0e72e0e0f0eec99',1,'FileSurfer.Models.ClipboardManager.Paste()'],['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a85db53191b994db578a250f0c75d9487',1,'FileSurfer.ViewModels.MainWindowViewModel.Paste()']]],
  ['pastefromosclipboard_1',['PasteFromOSClipboard',['../class_file_surfer_1_1_models_1_1_clipboard_manager.html#ab43cd36ab2bc7aa55b19af6ec1a2a6b3',1,'FileSurfer::Models::ClipboardManager']]],
  ['pintoquickaccess_2',['PinToQuickAccess',['../class_file_surfer_1_1_views_1_1_main_window.html#aa503d33d9b518eca4f0deaacebc42b95',1,'FileSurfer::Views::MainWindow']]],
  ['pull_3',['Pull',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#acf454a1553b97ca11c3dc8f3563ec80e',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['push_4',['Push',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a6e408a9273a97668f16c575d3fded882',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
