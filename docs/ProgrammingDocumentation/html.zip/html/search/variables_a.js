var searchData=
[
  ['pathcolumn_0',['PathColumn',['../class_file_surfer_1_1_models_1_1_windows_file_restorer.html#a55cd037364bedb8152547c139f4540ba',1,'FileSurfer::Models::WindowsFileRestorer']]],
  ['pathtoentry_1',['PathToEntry',['../class_file_surfer_1_1_file_system_entry.html#a1412300dfcd381a4eb999db9dc1376b7',1,'FileSurfer::FileSystemEntry']]]
];
