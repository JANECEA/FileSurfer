var searchData=
[
  ['ifileiohandler_2ecs_0',['IFileIOHandler.cs',['../_i_file_i_o_handler_8cs.html',1,'']]],
  ['iundoablefileoperation_2ecs_1',['IUndoableFileOperation.cs',['../_i_undoable_file_operation_8cs.html',1,'']]],
  ['iversioncontrol_2ecs_2',['IVersionControl.cs',['../_i_version_control_8cs.html',1,'']]]
];
