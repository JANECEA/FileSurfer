var searchData=
[
  ['filesdoubletapped_0',['FilesDoubleTapped',['../class_file_surfer_1_1_views_1_1_main_window.html#ab65ab93569733b0f3ab912e0479ce3f1',1,'FileSurfer::Views::MainWindow']]],
  ['filestapped_1',['FilesTapped',['../class_file_surfer_1_1_views_1_1_main_window.html#a734c1b3ee0ef12da30aadcf745c250ca',1,'FileSurfer::Views::MainWindow']]],
  ['filesystementry_2',['FileSystemEntry',['../class_file_surfer_1_1_file_system_entry.html#a80dab995dc18d33e7a8e58872ded38b1',1,'FileSurfer.FileSystemEntry.FileSystemEntry(IFileIOHandler fileIOHandler, string path, bool isDirectory, VCStatus status=VCStatus.NotVersionControlled)'],['../class_file_surfer_1_1_file_system_entry.html#abff8da81b1888f32214722564d416c3b',1,'FileSurfer.FileSystemEntry.FileSystemEntry(DriveInfo drive)']]],
  ['findwrappanel_3',['FindWrapPanel',['../class_file_surfer_1_1_views_1_1_main_window.html#a38baa04e7c0d68fb5b6c970a8215c5ef',1,'FileSurfer::Views::MainWindow']]]
];
