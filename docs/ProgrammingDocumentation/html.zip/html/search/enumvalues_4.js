var searchData=
[
  ['size_0',['Size',['../namespace_file_surfer.html#a7d93fd9e0886998da504a63742727e69a6f6cb72d544962fa333e2e34ce64f719',1,'FileSurfer']]],
  ['staged_1',['Staged',['../namespace_file_surfer_1_1_models.html#ae3f244098519fa62bfa9be2c071da92ba44bc04de5a94daecaffe9c26f7746988',1,'FileSurfer::Models']]]
];
