var searchData=
[
  ['zipfiles_0',['ZipFiles',['../class_file_surfer_1_1_models_1_1_archive_manager.html#a7b6683b08a2cd1a5dc059ce3502d6c8c',1,'FileSurfer::Models::ArchiveManager']]]
];
