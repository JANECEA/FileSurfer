var searchData=
[
  ['fileentries_0',['FileEntries',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#af311b4260cd446a8ff9260935b41375c',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['filenamegenerator_1',['FileNameGenerator',['../class_file_surfer_1_1_models_1_1_file_name_generator.html',1,'FileSurfer::Models']]],
  ['filenamegenerator_2ecs_2',['FileNameGenerator.cs',['../_file_name_generator_8cs.html',1,'']]],
  ['filesdoubletapped_3',['FilesDoubleTapped',['../class_file_surfer_1_1_views_1_1_main_window.html#ab65ab93569733b0f3ab912e0479ce3f1',1,'FileSurfer::Views::MainWindow']]],
  ['filesizedisplaylimit_4',['FileSizeDisplayLimit',['../class_file_surfer_1_1_file_surfer_settings.html#aada112364b1d0f59160f81f8319397c1',1,'FileSurfer::FileSurferSettings']]],
  ['filestapped_5',['FilesTapped',['../class_file_surfer_1_1_views_1_1_main_window.html#a734c1b3ee0ef12da30aadcf745c250ca',1,'FileSurfer::Views::MainWindow']]],
  ['filesurfer_6',['FileSurfer',['../namespace_file_surfer.html',1,'']]],
  ['filesurfer_3a_3amodels_7',['Models',['../namespace_file_surfer_1_1_models.html',1,'FileSurfer']]],
  ['filesurfer_3a_3amodels_3a_3aundoablefileoperations_8',['UndoableFileOperations',['../namespace_file_surfer_1_1_models_1_1_undoable_file_operations.html',1,'FileSurfer::Models']]],
  ['filesurfer_3a_3aviewmodels_9',['ViewModels',['../namespace_file_surfer_1_1_view_models.html',1,'FileSurfer']]],
  ['filesurfer_3a_3aviews_10',['Views',['../namespace_file_surfer_1_1_views.html',1,'FileSurfer']]],
  ['filesurfersettings_11',['FileSurferSettings',['../class_file_surfer_1_1_file_surfer_settings.html',1,'FileSurfer']]],
  ['filesurfersettings_2ecs_12',['FileSurferSettings.cs',['../_file_surfer_settings_8cs.html',1,'']]],
  ['filesystementry_13',['FileSystemEntry',['../class_file_surfer_1_1_file_system_entry.html',1,'FileSurfer.FileSystemEntry'],['../class_file_surfer_1_1_file_system_entry.html#a80dab995dc18d33e7a8e58872ded38b1',1,'FileSurfer.FileSystemEntry.FileSystemEntry(IFileIOHandler fileIOHandler, string path, bool isDirectory, VCStatus status=VCStatus.NotVersionControlled)'],['../class_file_surfer_1_1_file_system_entry.html#abff8da81b1888f32214722564d416c3b',1,'FileSurfer.FileSystemEntry.FileSystemEntry(DriveInfo drive)']]],
  ['filesystementry_2ecs_14',['FileSystemEntry.cs',['../_file_system_entry_8cs.html',1,'']]],
  ['findwrappanel_15',['FindWrapPanel',['../class_file_surfer_1_1_views_1_1_main_window.html#a38baa04e7c0d68fb5b6c970a8215c5ef',1,'FileSurfer::Views::MainWindow']]],
  ['fmask_16',['fMask',['../struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#afea2908822a28c45e195dc5e8e7db4f4',1,'FileSurfer::Models::WindowsFileProperties::SHELLEXECUTEINFO']]]
];
