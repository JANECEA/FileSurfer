var searchData=
[
  ['mainwindow_2eaxaml_2ecs_0',['MainWindow.axaml.cs',['../_main_window_8axaml_8cs.html',1,'']]],
  ['mainwindowviewmodel_2ecs_1',['MainWindowViewModel.cs',['../_main_window_view_model_8cs.html',1,'']]]
];
