var searchData=
[
  ['vcstatus_0',['VCStatus',['../namespace_file_surfer_1_1_models.html#ae3f244098519fa62bfa9be2c071da92b',1,'FileSurfer::Models']]]
];
