var searchData=
[
  ['cbsize_0',['cbSize',['../struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a0fa0c2a3caf9d749d0350620ec9599d4',1,'FileSurfer::Models::WindowsFileProperties::SHELLEXECUTEINFO']]]
];
