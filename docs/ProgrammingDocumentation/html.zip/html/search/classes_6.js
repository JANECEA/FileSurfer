var searchData=
[
  ['ifileiohandler_0',['IFileIOHandler',['../interface_file_surfer_1_1_models_1_1_i_file_i_o_handler.html',1,'FileSurfer::Models']]],
  ['iundoablefileoperation_1',['IUndoableFileOperation',['../interface_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_i_undoable_file_operation.html',1,'FileSurfer::Models::UndoableFileOperations']]],
  ['iversioncontrol_2',['IVersionControl',['../interface_file_surfer_1_1_models_1_1_i_version_control.html',1,'FileSurfer::Models']]]
];
