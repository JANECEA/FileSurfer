var searchData=
[
  ['branches_0',['Branches',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a947a29d2da3712f10f5c35930adcbf17',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
