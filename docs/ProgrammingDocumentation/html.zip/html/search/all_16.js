var searchData=
[
  ['windowsfileiohandler_0',['WindowsFileIOHandler',['../class_file_surfer_1_1_models_1_1_windows_file_i_o_handler.html',1,'FileSurfer.Models.WindowsFileIOHandler'],['../class_file_surfer_1_1_models_1_1_windows_file_i_o_handler.html#a397cf8d1d45ff1139d28310759ddd9e3',1,'FileSurfer.Models.WindowsFileIOHandler.WindowsFileIOHandler()']]],
  ['windowsfileiohandler_2ecs_1',['WindowsFileIOHandler.cs',['../_windows_file_i_o_handler_8cs.html',1,'']]],
  ['windowsfileproperties_2',['WindowsFileProperties',['../class_file_surfer_1_1_models_1_1_windows_file_properties.html',1,'FileSurfer::Models']]],
  ['windowsfilerestorer_3',['WindowsFileRestorer',['../class_file_surfer_1_1_models_1_1_windows_file_restorer.html',1,'FileSurfer::Models']]],
  ['windowsfilerestorer_2ecs_4',['WindowsFileRestorer.cs',['../_windows_file_restorer_8cs.html',1,'']]],
  ['windowsshellhandler_2ecs_5',['WindowsShellHandler.cs',['../_windows_shell_handler_8cs.html',1,'']]],
  ['wrappanelloaded_6',['WrapPanelLoaded',['../class_file_surfer_1_1_views_1_1_main_window.html#a50fd497d32a8ce01ae628fafa98a21fd',1,'FileSurfer::Views::MainWindow']]]
];
