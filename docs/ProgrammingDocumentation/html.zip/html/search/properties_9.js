var searchData=
[
  ['movetotrashcommand_0',['MoveToTrashCommand',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a2a5a5a56de046d6ff2bcbb76ac804007',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
