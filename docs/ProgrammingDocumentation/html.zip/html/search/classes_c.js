var searchData=
[
  ['undoredohandler_0',['UndoRedoHandler',['../class_file_surfer_1_1_models_1_1_undo_redo_handler.html',1,'FileSurfer::Models']]],
  ['undoredohandler_3c_20iundoablefileoperation_20_3e_1',['UndoRedoHandler&lt; IUndoableFileOperation &gt;',['../class_file_surfer_1_1_models_1_1_undo_redo_handler.html',1,'FileSurfer::Models']]],
  ['undoredohandler_3c_20string_20_3e_2',['UndoRedoHandler&lt; string &gt;',['../class_file_surfer_1_1_models_1_1_undo_redo_handler.html',1,'FileSurfer::Models']]],
  ['undoredonode_3',['UndoRedoNode',['../class_file_surfer_1_1_models_1_1_undo_redo_handler_1_1_undo_redo_node.html',1,'FileSurfer::Models::UndoRedoHandler']]]
];
