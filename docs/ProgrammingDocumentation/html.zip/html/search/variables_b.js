var searchData=
[
  ['restoreverb_0',['RestoreVerb',['../class_file_surfer_1_1_models_1_1_windows_file_restorer.html#ac9f60985469bb913cd19c3f92d077f0d',1,'FileSurfer::Models::WindowsFileRestorer']]]
];
