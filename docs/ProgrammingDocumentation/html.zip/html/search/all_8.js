var searchData=
[
  ['hicon_0',['hIcon',['../struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#acf758bf4a502b2d77a9af07b4c11ec21',1,'FileSurfer::Models::WindowsFileProperties::SHELLEXECUTEINFO']]],
  ['hinstapp_1',['hInstApp',['../struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a315101d1f76221ff55fb939b253f3274',1,'FileSurfer::Models::WindowsFileProperties::SHELLEXECUTEINFO']]],
  ['hkeyclass_2',['hkeyClass',['../struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a7b2ef62129fc37d77906ce592dd5b423',1,'FileSurfer::Models::WindowsFileProperties::SHELLEXECUTEINFO']]],
  ['hprocess_3',['hProcess',['../struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#aced7e36faf7aed2ece230489b2703fdd',1,'FileSurfer::Models::WindowsFileProperties::SHELLEXECUTEINFO']]],
  ['hwnd_4',['hwnd',['../struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a1b0f13d0a949d260528e198f782fb0e3',1,'FileSurfer::Models::WindowsFileProperties::SHELLEXECUTEINFO']]]
];
