var searchData=
[
  ['name_0',['Name',['../namespace_file_surfer.html#a7d93fd9e0886998da504a63742727e69a49ee3087348e8d44e1feda1917443987',1,'FileSurfer']]],
  ['notversioncontrolled_1',['NotVersionControlled',['../namespace_file_surfer_1_1_models.html#ae3f244098519fa62bfa9be2c071da92bac26158fd1d189f902f25e986b13c0ce0',1,'FileSurfer::Models']]]
];
