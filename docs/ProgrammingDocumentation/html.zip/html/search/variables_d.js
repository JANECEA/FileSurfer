var searchData=
[
  ['thispclabel_0',['ThisPCLabel',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#a7bb1d8e9fefe571ef58da14f5cb12ca3',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
