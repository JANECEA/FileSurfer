var searchData=
[
  ['gitversioncontrolhandler_2ecs_0',['GitVersionControlHandler.cs',['../_git_version_control_handler_8cs.html',1,'']]]
];
