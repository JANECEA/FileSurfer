var searchData=
[
  ['icon_0',['Icon',['../class_file_surfer_1_1_file_system_entry.html#a5d500d9480e0ce99883230dcc578feee',1,'FileSurfer::FileSystemEntry']]],
  ['invertselectioncommand_1',['InvertSelectionCommand',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#afd0afa7ab802d1167f7af563026dca29',1,'FileSurfer::ViewModels::MainWindowViewModel']]],
  ['isarchived_2',['IsArchived',['../class_file_surfer_1_1_file_system_entry.html#ad837e4da4e178dfe04ddfab30acdf123',1,'FileSurfer::FileSystemEntry']]],
  ['iscutoperation_3',['IsCutOperation',['../class_file_surfer_1_1_models_1_1_clipboard_manager.html#adcce936d4ab1ec3cb9a62d821f5409fe',1,'FileSurfer::Models::ClipboardManager']]],
  ['isdirectory_4',['IsDirectory',['../class_file_surfer_1_1_file_system_entry.html#a5e7c71bbe6f773038af2db0a7424cfda',1,'FileSurfer::FileSystemEntry']]],
  ['isversioncontrolled_5',['IsVersionControlled',['../class_file_surfer_1_1_view_models_1_1_main_window_view_model.html#aba8d6fca72e535ad166f84417d54fecd',1,'FileSurfer::ViewModels::MainWindowViewModel']]]
];
