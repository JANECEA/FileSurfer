var searchData=
[
  ['lastmodified_0',['LastModified',['../class_file_surfer_1_1_file_system_entry.html#a44209706ff33f6fb23aea7cddc26ed77',1,'FileSurfer::FileSystemEntry']]],
  ['lastmodtime_1',['LastModTime',['../class_file_surfer_1_1_file_system_entry.html#a172515131dfedad3f4edb92913e1afc3',1,'FileSurfer::FileSystemEntry']]]
];
