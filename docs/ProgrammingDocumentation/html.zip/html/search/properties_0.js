var searchData=
[
  ['allowimagepastingfromclipboard_0',['AllowImagePastingFromClipboard',['../class_file_surfer_1_1_file_surfer_settings.html#a7cac5a15f10697f1b616d449c91ad7d8',1,'FileSurfer::FileSurferSettings']]],
  ['automaticrefresh_1',['AutomaticRefresh',['../class_file_surfer_1_1_file_surfer_settings.html#a77be00f3ae886380a31579e446a6d516',1,'FileSurfer::FileSurferSettings']]],
  ['automaticrefreshinterval_2',['AutomaticRefreshInterval',['../class_file_surfer_1_1_file_surfer_settings.html#a77b4f166728e140e28030c75ef29930a',1,'FileSurfer::FileSurferSettings']]]
];
