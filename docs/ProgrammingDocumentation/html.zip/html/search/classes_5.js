var searchData=
[
  ['gitversioncontrolhandler_0',['GitVersionControlHandler',['../class_file_surfer_1_1_models_1_1_git_version_control_handler.html',1,'FileSurfer::Models']]]
];
