var namespaces_dup =
[
    [ "FileSurfer", "namespace_file_surfer.html", "namespace_file_surfer" ]
];