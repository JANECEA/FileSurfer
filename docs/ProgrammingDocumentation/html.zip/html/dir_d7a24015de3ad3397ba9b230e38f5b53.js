var dir_d7a24015de3ad3397ba9b230e38f5b53 =
[
    [ "IFileIOHandler.cs", "_i_file_i_o_handler_8cs.html", "_i_file_i_o_handler_8cs" ],
    [ "IUndoableFileOperation.cs", "_i_undoable_file_operation_8cs.html", "_i_undoable_file_operation_8cs" ],
    [ "IVersionControl.cs", "_i_version_control_8cs.html", "_i_version_control_8cs" ]
];