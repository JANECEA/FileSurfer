var class_file_surfer_1_1_models_1_1_file_name_generator =
[
    [ "CanBeRenamedCollectively", "class_file_surfer_1_1_models_1_1_file_name_generator.html#a9418e2bf14d3aaeb29aa77f2ffc48da5", null ],
    [ "GetAvailableName", "class_file_surfer_1_1_models_1_1_file_name_generator.html#ab34efef01ff90608030fc26f1c0290aa", null ],
    [ "GetAvailableNames", "class_file_surfer_1_1_models_1_1_file_name_generator.html#a35be5b4b0375981676c49b524c65f16c", null ],
    [ "GetCopyName", "class_file_surfer_1_1_models_1_1_file_name_generator.html#a5f35b45425c9201e3deb68520c1ad0f0", null ]
];