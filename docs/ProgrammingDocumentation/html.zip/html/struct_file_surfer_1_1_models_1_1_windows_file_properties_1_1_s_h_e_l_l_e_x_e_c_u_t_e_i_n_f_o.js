var struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o =
[
    [ "cbSize", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a0fa0c2a3caf9d749d0350620ec9599d4", null ],
    [ "dwHotKey", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#aaa2ba2e5ca65e05dad2fe65b2d21c2f5", null ],
    [ "fMask", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#afea2908822a28c45e195dc5e8e7db4f4", null ],
    [ "hIcon", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#acf758bf4a502b2d77a9af07b4c11ec21", null ],
    [ "hInstApp", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a315101d1f76221ff55fb939b253f3274", null ],
    [ "hkeyClass", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a7b2ef62129fc37d77906ce592dd5b423", null ],
    [ "hProcess", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#aced7e36faf7aed2ece230489b2703fdd", null ],
    [ "hwnd", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a1b0f13d0a949d260528e198f782fb0e3", null ],
    [ "lpClass", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a5f3291176bc0e254bdcbc70b2f668dd0", null ],
    [ "lpDirectory", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a390bfcbfa92f6c6b57b62763024a1212", null ],
    [ "lpFile", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#acd73ffa15a433c7edb416b0936ac13fe", null ],
    [ "lpIDList", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a8f77b4cc1702e0e54262c0660b2791b0", null ],
    [ "lpParameters", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a65f41f48569ab33a5404b855b13f3f23", null ],
    [ "lpVerb", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#a0c4e8119a2e29765039af517b61b7fb8", null ],
    [ "nShow", "struct_file_surfer_1_1_models_1_1_windows_file_properties_1_1_s_h_e_l_l_e_x_e_c_u_t_e_i_n_f_o.html#ac28e4faef1113a97588b69783321abeb", null ]
];