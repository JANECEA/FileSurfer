var _windows_file_restorer_8cs =
[
    [ "FileSurfer.Models.WindowsFileRestorer", "class_file_surfer_1_1_models_1_1_windows_file_restorer.html", "class_file_surfer_1_1_models_1_1_windows_file_restorer" ]
];