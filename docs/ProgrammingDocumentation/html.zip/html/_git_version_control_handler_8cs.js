var _git_version_control_handler_8cs =
[
    [ "FileSurfer.Models.GitVersionControlHandler", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html", "class_file_surfer_1_1_models_1_1_git_version_control_handler" ],
    [ "VCStatus", "_git_version_control_handler_8cs.html#ae3f244098519fa62bfa9be2c071da92b", [
      [ "NotVersionControlled", "_git_version_control_handler_8cs.html#ae3f244098519fa62bfa9be2c071da92bac26158fd1d189f902f25e986b13c0ce0", null ],
      [ "Staged", "_git_version_control_handler_8cs.html#ae3f244098519fa62bfa9be2c071da92ba44bc04de5a94daecaffe9c26f7746988", null ],
      [ "Unstaged", "_git_version_control_handler_8cs.html#ae3f244098519fa62bfa9be2c071da92bad9c90a7d6a180b805c17ef41e4154095", null ]
    ] ]
];