var _main_window_view_model_8cs =
[
    [ "FileSurfer.ViewModels.MainWindowViewModel", "class_file_surfer_1_1_view_models_1_1_main_window_view_model.html", "class_file_surfer_1_1_view_models_1_1_main_window_view_model" ]
];