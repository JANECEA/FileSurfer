var files_dup =
[
    [ "Interfaces", "dir_d7a24015de3ad3397ba9b230e38f5b53.html", "dir_d7a24015de3ad3397ba9b230e38f5b53" ],
    [ "Models", "dir_22305cb0964bbe63c21991dd2265ce48.html", "dir_22305cb0964bbe63c21991dd2265ce48" ],
    [ "ViewModels", "dir_ba262fc08cc173e800721160247391b9.html", "dir_ba262fc08cc173e800721160247391b9" ],
    [ "Views", "dir_e47e4de72e0320db55f81376ac4f26ec.html", "dir_e47e4de72e0320db55f81376ac4f26ec" ],
    [ "App.axaml.cs", "_app_8axaml_8cs.html", "_app_8axaml_8cs" ],
    [ "FileSurferSettings.cs", "_file_surfer_settings_8cs.html", "_file_surfer_settings_8cs" ],
    [ "FileSystemEntry.cs", "_file_system_entry_8cs.html", "_file_system_entry_8cs" ],
    [ "Program.cs", "_program_8cs.html", "_program_8cs" ],
    [ "ViewLocator.cs", "_view_locator_8cs.html", "_view_locator_8cs" ]
];