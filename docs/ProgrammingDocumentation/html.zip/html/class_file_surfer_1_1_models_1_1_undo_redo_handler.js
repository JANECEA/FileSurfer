var class_file_surfer_1_1_models_1_1_undo_redo_handler =
[
    [ "UndoRedoNode", "class_file_surfer_1_1_models_1_1_undo_redo_handler_1_1_undo_redo_node.html", null ],
    [ "UndoRedoHandler", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a729e28486e6382ee83eb64aed02ade46", null ],
    [ "AddNewNode", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a6333768d7bad71ae8a3b2d39ffccbfcc", null ],
    [ "GetNext", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a402290ac3db4ef1ed7ce22300d6578ac", null ],
    [ "GetPrevious", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#aecef0f37e363ba36310ad61c0978c6c9", null ],
    [ "IsHead", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#afc2afeeaaa5dad66b8e9abdd2b399309", null ],
    [ "IsTail", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#aa289dca6e1d312a9454c0d176cb50b2e", null ],
    [ "MoveToNext", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a349a2e7ac51f0f3b46e83aeaefa8abd5", null ],
    [ "MoveToPrevious", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a2df4aabdded2febbbfee29350637fbb3", null ],
    [ "RemoveNode", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a168d284f070c3fc7685320e9a1ecbdb9", null ],
    [ "_current", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a92c12b1f190ea22dd5d3a15a805d7cfd", null ],
    [ "_head", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#afc4cb36a0c594dca475b1296861eadf0", null ],
    [ "_tail", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a180ba59c9fe368e7480d8f051e548394", null ],
    [ "Current", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html#a18e4c18db6c30fe9fb56c69862f76e2d", null ]
];