var _undo_redo_handler_8cs =
[
    [ "FileSurfer.Models.UndoRedoHandler< T >", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html", "class_file_surfer_1_1_models_1_1_undo_redo_handler" ],
    [ "FileSurfer.Models.UndoRedoHandler< T >.UndoRedoNode", "class_file_surfer_1_1_models_1_1_undo_redo_handler_1_1_undo_redo_node.html", null ]
];