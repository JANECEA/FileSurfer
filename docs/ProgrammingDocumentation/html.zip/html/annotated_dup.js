var annotated_dup =
[
    [ "FileSurfer", "namespace_file_surfer.html", [
      [ "Models", "namespace_file_surfer_1_1_models.html", [
        [ "UndoableFileOperations", "namespace_file_surfer_1_1_models_1_1_undoable_file_operations.html", [
          [ "CopyFilesTo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to" ],
          [ "DuplicateFiles", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files" ],
          [ "IUndoableFileOperation", "interface_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_i_undoable_file_operation.html", "interface_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_i_undoable_file_operation" ],
          [ "MoveFilesTo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to" ],
          [ "MoveFilesToTrash", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash" ],
          [ "NewDirAt", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_dir_at.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_dir_at" ],
          [ "NewFileAt", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_file_at.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_file_at" ],
          [ "RenameMultiple", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_multiple.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_multiple" ],
          [ "RenameOne", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one" ]
        ] ],
        [ "ArchiveManager", "class_file_surfer_1_1_models_1_1_archive_manager.html", "class_file_surfer_1_1_models_1_1_archive_manager" ],
        [ "ClipboardManager", "class_file_surfer_1_1_models_1_1_clipboard_manager.html", "class_file_surfer_1_1_models_1_1_clipboard_manager" ],
        [ "FileNameGenerator", "class_file_surfer_1_1_models_1_1_file_name_generator.html", "class_file_surfer_1_1_models_1_1_file_name_generator" ],
        [ "GitVersionControlHandler", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html", "class_file_surfer_1_1_models_1_1_git_version_control_handler" ],
        [ "IFileIOHandler", "interface_file_surfer_1_1_models_1_1_i_file_i_o_handler.html", "interface_file_surfer_1_1_models_1_1_i_file_i_o_handler" ],
        [ "IVersionControl", "interface_file_surfer_1_1_models_1_1_i_version_control.html", "interface_file_surfer_1_1_models_1_1_i_version_control" ],
        [ "UndoRedoHandler", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html", "class_file_surfer_1_1_models_1_1_undo_redo_handler" ],
        [ "WindowsFileIOHandler", "class_file_surfer_1_1_models_1_1_windows_file_i_o_handler.html", "class_file_surfer_1_1_models_1_1_windows_file_i_o_handler" ],
        [ "WindowsFileProperties", "class_file_surfer_1_1_models_1_1_windows_file_properties.html", "class_file_surfer_1_1_models_1_1_windows_file_properties" ],
        [ "WindowsFileRestorer", "class_file_surfer_1_1_models_1_1_windows_file_restorer.html", "class_file_surfer_1_1_models_1_1_windows_file_restorer" ]
      ] ],
      [ "ViewModels", "namespace_file_surfer_1_1_view_models.html", [
        [ "MainWindowViewModel", "class_file_surfer_1_1_view_models_1_1_main_window_view_model.html", "class_file_surfer_1_1_view_models_1_1_main_window_view_model" ]
      ] ],
      [ "Views", "namespace_file_surfer_1_1_views.html", [
        [ "ErrorWindow", "class_file_surfer_1_1_views_1_1_error_window.html", "class_file_surfer_1_1_views_1_1_error_window" ],
        [ "MainWindow", "class_file_surfer_1_1_views_1_1_main_window.html", "class_file_surfer_1_1_views_1_1_main_window" ]
      ] ],
      [ "App", "class_file_surfer_1_1_app.html", "class_file_surfer_1_1_app" ],
      [ "FileSurferSettings", "class_file_surfer_1_1_file_surfer_settings.html", "class_file_surfer_1_1_file_surfer_settings" ],
      [ "FileSystemEntry", "class_file_surfer_1_1_file_system_entry.html", "class_file_surfer_1_1_file_system_entry" ],
      [ "Program", "class_file_surfer_1_1_program.html", "class_file_surfer_1_1_program" ],
      [ "ViewLocator", "class_file_surfer_1_1_view_locator.html", "class_file_surfer_1_1_view_locator" ]
    ] ]
];