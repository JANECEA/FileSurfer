var interface_file_surfer_1_1_models_1_1_i_version_control =
[
    [ "CommitChanges", "interface_file_surfer_1_1_models_1_1_i_version_control.html#afb9b709d9af61d6622bf726742764b5f", null ],
    [ "ConsolidateStatus", "interface_file_surfer_1_1_models_1_1_i_version_control.html#a13db52e3d67fdd01483fb4e75849d317", null ],
    [ "DownloadChanges", "interface_file_surfer_1_1_models_1_1_i_version_control.html#abc780dfd96c7e9a632547aaf418fb3db", null ],
    [ "GetBranches", "interface_file_surfer_1_1_models_1_1_i_version_control.html#ad68a79ec5ef88a0a56ba49ae1eb7590a", null ],
    [ "GetCurrentBranchName", "interface_file_surfer_1_1_models_1_1_i_version_control.html#ae12a0b0df34cc6b0af2934e8f15f00d0", null ],
    [ "IsVersionControlled", "interface_file_surfer_1_1_models_1_1_i_version_control.html#a3b7c713fe5bd831ddd0993b8dde32d9d", null ],
    [ "StageChange", "interface_file_surfer_1_1_models_1_1_i_version_control.html#add2249de02b5154666d32b40e84baed8", null ],
    [ "SwitchBranches", "interface_file_surfer_1_1_models_1_1_i_version_control.html#a1af25a0348ba0449f200566448049cd4", null ],
    [ "UnstageChange", "interface_file_surfer_1_1_models_1_1_i_version_control.html#a74db356e0e8d989c712d91620a9fcde5", null ],
    [ "UploadChanges", "interface_file_surfer_1_1_models_1_1_i_version_control.html#af5c761659d848948a5de4be27c6a9cc7", null ]
];