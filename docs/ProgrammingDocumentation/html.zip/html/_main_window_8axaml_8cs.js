var _main_window_8axaml_8cs =
[
    [ "FileSurfer.Views.MainWindow", "class_file_surfer_1_1_views_1_1_main_window.html", "class_file_surfer_1_1_views_1_1_main_window" ]
];