var _undoable_file_operations_8cs =
[
    [ "FileSurfer.Models.UndoableFileOperations.MoveFilesToTrash", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to_trash" ],
    [ "FileSurfer.Models.UndoableFileOperations.MoveFilesTo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_move_files_to" ],
    [ "FileSurfer.Models.UndoableFileOperations.CopyFilesTo", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_copy_files_to" ],
    [ "FileSurfer.Models.UndoableFileOperations.DuplicateFiles", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_duplicate_files" ],
    [ "FileSurfer.Models.UndoableFileOperations.RenameMultiple", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_multiple.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_multiple" ],
    [ "FileSurfer.Models.UndoableFileOperations.RenameOne", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_rename_one" ],
    [ "FileSurfer.Models.UndoableFileOperations.NewFileAt", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_file_at.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_file_at" ],
    [ "FileSurfer.Models.UndoableFileOperations.NewDirAt", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_dir_at.html", "class_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_new_dir_at" ]
];