var class_file_surfer_1_1_models_1_1_git_version_control_handler =
[
    [ "GitVersionControlHandler", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a4d0f45c39a4f4678c00cb6f76d2380fb", null ],
    [ "CommitChanges", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#ae9c2995af4e9a28367f9a5e84eeda998", null ],
    [ "ConsolidateStatus", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a22fdd066414ba5cd2ad4aea2bd702512", null ],
    [ "ConvertToVCStatus", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#ab110275371b3a83a3f6a3613e2a76908", null ],
    [ "Dispose", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#afe047b4c604c2123e3c307abd823c2d4", null ],
    [ "DownloadChanges", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#aab2ce51d78e6c54658bafc600ed75276", null ],
    [ "GetBranches", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#abe12e7240b968e24efa9a7cd6f0b77ba", null ],
    [ "GetCurrentBranchName", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a3914a62685b5477d7a5977448ba0bb64", null ],
    [ "IsVersionControlled", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a25744e9a755cb6c3ba4b03dd148e074c", null ],
    [ "SetFileStates", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a8fbaa155d9fcae851c6fb8acaad40236", null ],
    [ "StageChange", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a959564d432fbaefeeb6469b6a5f20618", null ],
    [ "SwitchBranches", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a7bfbce5f680eb08686afa8d2d467d7f4", null ],
    [ "UnstageChange", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#af752574976267d05d05c879eab5f8ccc", null ],
    [ "UploadChanges", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a406442d981f15e6af1a003569fe5f555", null ],
    [ "_currentRepo", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#adab5decfdef445097c453df9abe3f41c", null ],
    [ "_fileIOHandler", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a76142e78896871eca3601abb1fec1311", null ],
    [ "_statusDict", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a44a3bfd99a5bcb3300b19472da8d4c78", null ],
    [ "MissingRepoMessage", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html#a97dc33df11ed92013631ab84a78e8cb1", null ]
];