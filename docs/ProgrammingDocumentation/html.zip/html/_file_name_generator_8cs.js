var _file_name_generator_8cs =
[
    [ "FileSurfer.Models.FileNameGenerator", "class_file_surfer_1_1_models_1_1_file_name_generator.html", "class_file_surfer_1_1_models_1_1_file_name_generator" ]
];