var namespace_file_surfer =
[
    [ "Models", "namespace_file_surfer_1_1_models.html", "namespace_file_surfer_1_1_models" ],
    [ "ViewModels", "namespace_file_surfer_1_1_view_models.html", "namespace_file_surfer_1_1_view_models" ],
    [ "Views", "namespace_file_surfer_1_1_views.html", "namespace_file_surfer_1_1_views" ],
    [ "App", "class_file_surfer_1_1_app.html", "class_file_surfer_1_1_app" ],
    [ "FileSurferSettings", "class_file_surfer_1_1_file_surfer_settings.html", "class_file_surfer_1_1_file_surfer_settings" ],
    [ "FileSystemEntry", "class_file_surfer_1_1_file_system_entry.html", "class_file_surfer_1_1_file_system_entry" ],
    [ "Program", "class_file_surfer_1_1_program.html", "class_file_surfer_1_1_program" ],
    [ "ViewLocator", "class_file_surfer_1_1_view_locator.html", "class_file_surfer_1_1_view_locator" ],
    [ "DisplayModeEnum", "namespace_file_surfer.html#add75a44e500cbc07ebc69ace0726976e", [
      [ "ListView", "namespace_file_surfer.html#add75a44e500cbc07ebc69ace0726976ea416c421e722428b4f6e0863f98a25cff", null ],
      [ "IconView", "namespace_file_surfer.html#add75a44e500cbc07ebc69ace0726976eac689f85d431a8db0da40fceda311eeec", null ]
    ] ],
    [ "SortBy", "namespace_file_surfer.html#a7d93fd9e0886998da504a63742727e69", [
      [ "Name", "namespace_file_surfer.html#a7d93fd9e0886998da504a63742727e69a49ee3087348e8d44e1feda1917443987", null ],
      [ "Date", "namespace_file_surfer.html#a7d93fd9e0886998da504a63742727e69a44749712dbec183e983dcd78a7736c41", null ],
      [ "Type", "namespace_file_surfer.html#a7d93fd9e0886998da504a63742727e69aa1fa27779242b4902f7ae3bdd5c6d508", null ],
      [ "Size", "namespace_file_surfer.html#a7d93fd9e0886998da504a63742727e69a6f6cb72d544962fa333e2e34ce64f719", null ]
    ] ]
];