var namespace_file_surfer_1_1_models =
[
    [ "UndoableFileOperations", "namespace_file_surfer_1_1_models_1_1_undoable_file_operations.html", "namespace_file_surfer_1_1_models_1_1_undoable_file_operations" ],
    [ "ArchiveManager", "class_file_surfer_1_1_models_1_1_archive_manager.html", "class_file_surfer_1_1_models_1_1_archive_manager" ],
    [ "ClipboardManager", "class_file_surfer_1_1_models_1_1_clipboard_manager.html", "class_file_surfer_1_1_models_1_1_clipboard_manager" ],
    [ "FileNameGenerator", "class_file_surfer_1_1_models_1_1_file_name_generator.html", "class_file_surfer_1_1_models_1_1_file_name_generator" ],
    [ "GitVersionControlHandler", "class_file_surfer_1_1_models_1_1_git_version_control_handler.html", "class_file_surfer_1_1_models_1_1_git_version_control_handler" ],
    [ "IFileIOHandler", "interface_file_surfer_1_1_models_1_1_i_file_i_o_handler.html", "interface_file_surfer_1_1_models_1_1_i_file_i_o_handler" ],
    [ "IVersionControl", "interface_file_surfer_1_1_models_1_1_i_version_control.html", "interface_file_surfer_1_1_models_1_1_i_version_control" ],
    [ "UndoRedoHandler", "class_file_surfer_1_1_models_1_1_undo_redo_handler.html", "class_file_surfer_1_1_models_1_1_undo_redo_handler" ],
    [ "WindowsFileIOHandler", "class_file_surfer_1_1_models_1_1_windows_file_i_o_handler.html", "class_file_surfer_1_1_models_1_1_windows_file_i_o_handler" ],
    [ "WindowsFileProperties", "class_file_surfer_1_1_models_1_1_windows_file_properties.html", "class_file_surfer_1_1_models_1_1_windows_file_properties" ],
    [ "WindowsFileRestorer", "class_file_surfer_1_1_models_1_1_windows_file_restorer.html", "class_file_surfer_1_1_models_1_1_windows_file_restorer" ],
    [ "VCStatus", "namespace_file_surfer_1_1_models.html#ae3f244098519fa62bfa9be2c071da92b", [
      [ "NotVersionControlled", "namespace_file_surfer_1_1_models.html#ae3f244098519fa62bfa9be2c071da92bac26158fd1d189f902f25e986b13c0ce0", null ],
      [ "Staged", "namespace_file_surfer_1_1_models.html#ae3f244098519fa62bfa9be2c071da92ba44bc04de5a94daecaffe9c26f7746988", null ],
      [ "Unstaged", "namespace_file_surfer_1_1_models.html#ae3f244098519fa62bfa9be2c071da92bad9c90a7d6a180b805c17ef41e4154095", null ]
    ] ]
];