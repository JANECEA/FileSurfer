var interface_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_i_undoable_file_operation =
[
    [ "Redo", "interface_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_i_undoable_file_operation.html#a53882a4d1ea2b7291d5e5eb7e639f65a", null ],
    [ "Undo", "interface_file_surfer_1_1_models_1_1_undoable_file_operations_1_1_i_undoable_file_operation.html#a7e00b4b016950bacceda39c5fac58657", null ]
];