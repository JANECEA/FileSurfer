var _file_surfer_settings_8cs =
[
    [ "FileSurfer.FileSurferSettings", "class_file_surfer_1_1_file_surfer_settings.html", "class_file_surfer_1_1_file_surfer_settings" ],
    [ "DisplayModeEnum", "_file_surfer_settings_8cs.html#add75a44e500cbc07ebc69ace0726976e", [
      [ "ListView", "_file_surfer_settings_8cs.html#add75a44e500cbc07ebc69ace0726976ea416c421e722428b4f6e0863f98a25cff", null ],
      [ "IconView", "_file_surfer_settings_8cs.html#add75a44e500cbc07ebc69ace0726976eac689f85d431a8db0da40fceda311eeec", null ]
    ] ],
    [ "SortBy", "_file_surfer_settings_8cs.html#a7d93fd9e0886998da504a63742727e69", [
      [ "Name", "_file_surfer_settings_8cs.html#a7d93fd9e0886998da504a63742727e69a49ee3087348e8d44e1feda1917443987", null ],
      [ "Date", "_file_surfer_settings_8cs.html#a7d93fd9e0886998da504a63742727e69a44749712dbec183e983dcd78a7736c41", null ],
      [ "Type", "_file_surfer_settings_8cs.html#a7d93fd9e0886998da504a63742727e69aa1fa27779242b4902f7ae3bdd5c6d508", null ],
      [ "Size", "_file_surfer_settings_8cs.html#a7d93fd9e0886998da504a63742727e69a6f6cb72d544962fa333e2e34ce64f719", null ]
    ] ]
];